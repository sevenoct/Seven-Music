//! Network side: a small tokio runtime talking to YouTube Music (`ytmapi`/`ytm`).
//!
//! The UI sends `Req`s and drains `Resp`s once per frame; every response wakes the UI.
//! Playback resolution also lives here: resolve stream → start progressive download →
//! build the decoder on a blocking thread → hand it to the audio engine.

use std::path::PathBuf;
use std::sync::Arc;
use std::sync::atomic::Ordering;

use crossbeam_channel::Sender;
use tokio::runtime::Runtime;

use crate::art::Art;
use crate::audio::{AudioCmd, AudioHandle};
use crate::lyrics::{self, LyricsSet};
use crate::model::{self, Card, Target, Thumb, Track, sized};
use crate::stream::{self, Shared};
use crate::{hires, innertube, jsc, webmusic, ytdlp, ytm, ytmapi};

pub enum Req {
    /// Home feed, optionally filtered by a mood chip's params.
    Home(Option<String>),
    HomeMore(String),
    /// Explore's mood and genre list, for Home's mood tile.
    Moods,
    /// A mood played as a station: its playlists' songs, shuffled into one queue.
    MoodStation(ytm::Mood),
    MoreQuickPicks(String),
    Explore(Vec<String>),
    Search(String),
    /// Suggestions for a query; `round` comes back with them, so stale ones can be dropped.
    Suggest { query: String, round: u64 },
    /// Remove a past search (its token) from the account's history.
    ForgetSearch(String),
    /// `load` comes back with the album, so an older answer can't replace a newer one.
    Album { id: String, load: u64 },
    Artist(String),
    /// `stream`: send the first page as soon as it's in and the rest as they come,
    /// rather than all of it at the end.
    Playlist { id: String, load: u64, stream: bool },
    Library,
    History,
    /// Songs the account uploaded to YouTube Music.
    Uploads,
    /// The signed-in account's name and photo.
    Account,
    /// The channels the signed-in Google account can act as.
    Channels,
    /// Act as another of them from now on: a brand channel's page id, or `None` for the
    /// account's own channel. `epoch`: the list's, picked from.
    SwitchChannel { page_id: Option<String>, epoch: u64 },
    /// The queue another device left off with (YouTube Music's own cross-device queue).
    ServerQueue,
    /// Upload audio files to the account's library.
    Upload(Vec<PathBuf>),
    /// Save a song's audio to the downloads folder. `for_video`: the music video it's the
    /// song version of, which then plays it from the file (offline too).
    Download { track: Track, for_video: Option<String> },
    Lyrics { track: Track, generation: u64, genius_enabled: bool },
    /// The Genius description of this song, fetched on demand.
    GeniusAbout(Track),
    AppleAlbumAbout { id: String, title: String, artist: String },
    /// SponsorBlock's parts of a video to skip.
    Segments { video_id: String },
    /// youtube.com's "Most replayed" curve for one video: where people drag back to.
    BestPart(String),
    /// Whether YouTube's own description says AI made this video: the watch page's
    /// "Made with AI" block, which nothing in the song's own name has to repeat.
    AiCheck { video_id: String },
    /// Romanization and translation for the lyric lines of one source.
    LyricsExtras { video_id: String, source: String, lines: Vec<String>, lang: Option<String>, target: String },
    /// Process cover art for the background; `key` is echoed back.
    Art { key: String, url: String },
    /// Processed art for a page's own cover, which plays on nothing; `key` names the page.
    PageArt { key: String, url: String },
    /// Apple's artist page (display name and hero clips) for the artist `id`.
    AppleArtist { id: String, name: String },
    /// Apple's shelves for one of its browse pages (`new`, `radio`); the path comes back.
    AppleFeed(String),
    /// Apple's own collection page (an album or a playlist), read from the page itself.
    AppleCollection { url: String },
    /// Play an Apple collection's songs: each one found on the source that has it.
    AppleSongs { target: Target, songs: Vec<crate::apple::AppleSong> },
    /// YouTube Music's copy of something on Apple, as the target to open it as.
    AppleLookup(Target),
    /// Apple's motion sleeve for a release; `key` is what the UI asked for and
    /// `record` is Apple's own record id, which only a page opened from one of Apple's
    /// addresses can carry.
    AppleCover { key: String, album: String, artist: String, title: Option<String>, record: Option<String> },
    /// The music-video player's picture: YouTube Music's music video of this song, as a stream URL
    /// no wider than `width`. `key` is the song it was asked for, so a late answer can't
    /// land on another one.
    MusicVideo { key: String, track: Track, width: u32, skip: bool },
    /// Spotify's looping canvas for a song; `key` is the song it was asked for.
    Canvas { key: String, artist: String, title: String, ms: u64 },
    /// A handwritten signature for `name` from the service at `endpoint`; `key` is
    /// what the UI asked for.
    ArtistSignature { key: String, endpoint: String, name: String },
    /// Test a pasted hi-res source `link`; `key` is what the UI asked for.
    CheckHiResSource { key: String, link: String },
    /// Radio seeded from a track (`seed`, its id); appended to the queue. `song_of`: the
    /// track, when it's a music video to play as its song: the song's radio is asked for.
    Radio { seed: String, song_of: Option<Track> },
    /// Fetch an album/playlist and play it from the start.
    PlayCollection { target: Target },
    /// `at`: start position (non-zero when resuming last session's song). `report`: tell
    /// YouTube about the play (not when picking up a song already counted). `song_of`:
    /// the track, when it's a music video to play as its song version if one is found.
    /// `song`: the song version already playing for the music video `video_id` (picked up
    /// mid-song): played without a lookup, and the video if it won't. `track`: the song as
    /// the UI lists it, for a hi-res source's search.
    Play { video_id: String, generation: u64, at: std::time::Duration, report: bool, song_of: Option<Track>, song: Option<Track>, track: Option<Track> },
    /// Resolve and download a track ahead of time so skipping to it is instant.
    Prefetch { video_id: String, song_of: Option<Track>, track: Option<Track> },
    Like { video_id: String, like: bool },
    /// Several likes (or unlikes) one after another, for a selection.
    LikeMany { video_ids: Vec<String>, like: bool },
    Dislike(String),
    CreatePlaylist { title: String, video_ids: Vec<String> },
    EditPlaylist { id: String, title: String, description: String, privacy: Option<String> },
    AddToPlaylist { playlist_id: String, video_ids: Vec<String> },
    /// `(videoId, setVideoId)` entries to take out of the playlist.
    RemoveFromPlaylist { playlist_id: String, items: Vec<(String, String)> },
    DeletePlaylist(String),
    /// A playlist's collaboration settings and invite link.
    Collaboration(String),
    SetCollaboration { info: ytm::Collaboration, change: ytm::CollabChange },
    SaveCollection { id: String, save: bool },
    SetCookie(String),
    Logout,
}

impl Req {
    fn name(&self) -> &'static str {
        match self {
            Req::Home(_) | Req::HomeMore(_) => "Loading home",
            Req::Moods => "Loading moods",
            Req::MoodStation(_) => "Mood station",
            Req::MoreQuickPicks(_) => "Loading more picks",
            Req::Explore(_) => "Loading new",
            Req::Search(_) => "Search",
            Req::Suggest { .. } => "Suggest",
            Req::ForgetSearch(_) => "Removing the search",
            Req::Album { .. } => "Loading album",
            Req::Artist(_) => "Loading artist",
            Req::Playlist { .. } => "Loading playlist",
            Req::Library => "Loading library",
            Req::History => "Loading history",
            Req::Uploads => "Loading uploads",
            Req::Account => "Account",
            Req::Channels => "Channels",
            Req::SwitchChannel { .. } => "Switching channel",
            Req::ServerQueue => "Queue from other devices",
            Req::Upload(_) => "Upload",
            Req::Download { .. } => "Download",
            Req::Lyrics { .. } => "Lyrics",
            Req::GeniusAbout(_) => "Genius about",
            Req::AppleAlbumAbout { .. } => "Apple album about",
            Req::Segments { .. } => "SponsorBlock",
            Req::BestPart(_) => "Best part",
            Req::AiCheck { .. } => "AI label",
            Req::LyricsExtras { .. } => "Translation",
            Req::Art { .. } => "Art",
            Req::PageArt { .. } => "Page art",
            Req::AppleArtist { .. } => "Apple artist",
            Req::AppleFeed(_) => "Apple browse page",
            Req::AppleCollection { .. } => "Apple collection",
            Req::AppleSongs { .. } => "Apple songs",
            Req::AppleLookup(_) => "Apple lookup",
            Req::AppleCover { .. } => "Apple artwork",
            Req::MusicVideo { .. } => "Music video",
            Req::Canvas { .. } => "Spotify canvas",
            Req::ArtistSignature { .. } => "Artist signature",
            Req::CheckHiResSource { .. } => "Testing source",
            Req::Radio { .. } => "Loading radio",
            Req::PlayCollection { .. } => "Playback",
            Req::Play { .. } => "Playback",
            Req::Prefetch { .. } => "Prefetch",
            Req::Like { .. } | Req::LikeMany { .. } => "Like",
            Req::Dislike(_) => "Dislike",
            Req::CreatePlaylist { .. } => "Create playlist",
            Req::EditPlaylist { .. } => "Edit playlist",
            Req::AddToPlaylist { .. } => "Add to playlist",
            Req::RemoveFromPlaylist { .. } => "Remove from playlist",
            Req::DeletePlaylist(_) => "Delete playlist",
            Req::Collaboration(_) => "Loading collaboration",
            Req::SetCollaboration { .. } => "Collaboration",
            Req::SaveCollection { .. } => "Save to library",
            Req::SetCookie(_) => "Sign in",
            Req::Logout => "Sign out",
        }
    }

    /// Background requests fail quietly (logged, no toast).
    fn quiet(&self) -> bool {
        matches!(self, Req::Suggest { .. } | Req::Account | Req::Channels | Req::ServerQueue | Req::Art { .. } | Req::PageArt { .. } | Req::AppleArtist { .. } | Req::AppleFeed(_) | Req::AppleCollection { .. } | Req::AppleCover { .. } | Req::MusicVideo { .. } | Req::ArtistSignature { .. } | Req::CheckHiResSource { .. } | Req::Prefetch { .. } | Req::HomeMore(_) | Req::Moods | Req::Lyrics { .. } | Req::GeniusAbout(_) | Req::AppleAlbumAbout { .. } | Req::Segments { .. } | Req::AiCheck { .. } | Req::BestPart(_) | Req::LyricsExtras { .. })
    }
}

/// Whether Google and Apple mean the same thing by these two names.
fn same_name(a: &str, b: &str) -> bool {
    let (a, b) = (crate::apple::norm(a), crate::apple::norm(b));
    !a.is_empty() && !b.is_empty() && (a == b || a.contains(&b) || b.contains(&a))
}

/// Whether either of these artist lines names one of the other's.
fn near_artist(a: &str, b: &str) -> bool {
    let (x, y) = (crate::apple::norm(a), crate::apple::norm(b));
    if x.is_empty() || y.is_empty() {
        return false;
    }
    x.contains(&y) || y.contains(&x) || a.split(',').any(|p| {
        let p = crate::apple::norm(p);
        p.len() > 2 && y.contains(&p)
    })
}

pub struct Explore {
    pub new_albums: Vec<Card>,
    pub charts: Vec<Card>,
    pub top: Vec<Track>,
}

pub struct SearchResults {
    pub query: String,
    pub tracks: Vec<Track>,
    pub albums: Vec<Card>,
    pub artists: Vec<Card>,
    pub playlists: Vec<Card>,
}

/// Several relevance-ordered song lists, taken one row at a time in turn, so each keeps
/// its standing in the merged list. A row repeating a song already taken is dropped (a
/// video of the song that's already there).
fn weave(lists: Vec<Vec<Track>>) -> Vec<Track> {
    let mut out: Vec<Track> = Vec::new();
    let longest = lists.iter().map(Vec::len).max().unwrap_or(0);
    for i in 0..longest {
        for list in &lists {
            if let Some(t) = list.get(i) {
                if !out.iter().any(|x| x.id == t.id) {
                    out.push(t.clone());
                }
            }
        }
    }
    out
}

/// An album or playlist page.
pub struct Collection {
    pub id: String,
    pub is_album: bool,
    /// Album's playlist ID for saving it to the account library.
    pub save_id: Option<String>,
    pub title: String,
    pub subtitle: String,
    /// Album artists / playlist owner named in the subtitle, clickable.
    pub artists: Vec<model::Link>,
    pub description: Option<String>,
    pub thumbs: Vec<Thumb>,
    pub tracks: Vec<Track>,
    /// Each track's playlist entry id (`setVideoId`), for removing it; empty for albums.
    pub set_ids: Vec<Option<String>>,
    /// How many songs the playlist's header counts (unplayable ones too, so it can be more
    /// than `tracks`); kept in step with removals and unlikes made here.
    pub count: Option<u64>,
    /// The account's own playlist (editable), not one saved from someone else.
    pub owned: bool,
}

impl Collection {
    /// The subtitle, with the song count for a playlist.
    pub fn byline(&self) -> String {
        match self.count {
            Some(n) if self.subtitle.is_empty() => format!("{n} songs"),
            Some(n) => format!("{} • {n} songs", self.subtitle),
            None => self.subtitle.clone(),
        }
    }

    /// Take rows out (sorted indices), and out of the count.
    pub fn remove_rows(&mut self, rows: &[usize]) {
        for &i in rows.iter().rev() {
            if i < self.tracks.len() {
                self.tracks.remove(i);
                if i < self.set_ids.len() {
                    self.set_ids.remove(i);
                }
                self.count = self.count.map(|n| n.saturating_sub(1));
            }
        }
    }
}

pub struct ArtistPage {
    pub id: String,
    pub name: String,
    pub banner: Vec<Thumb>,
    pub description: Option<String>,
    pub top: Vec<Track>,
    /// "Top songs" playlist behind the shelf's Show all button.
    pub top_playlist: Option<String>,
    pub albums: Vec<Card>,
    pub playlists: Vec<Card>,
    pub similar: Vec<Card>,
}

pub struct Library {
    pub playlists: Vec<Card>,
    pub albums: Vec<Card>,
    /// That half didn't load (YouTube Music refused it, say): the one shown stays.
    pub playlists_failed: bool,
    pub albums_failed: bool,
}

/// The signed-in account's channels.
pub struct Channels {
    pub list: Vec<ytm::Channel>,
    /// The page id of the one requests go as (`None`: the account's own).
    pub current: Option<String>,
    /// [`ytmapi::Api::epoch`] when listed: a switch picked from here applies only then.
    pub epoch: u64,
}

pub enum Resp {
    Home(ytm::HomePage),
    HomeMore { token: String, page: ytm::HomePage },
    QuickPicksMore { seed: String, tracks: Vec<Track> },
    Explore(Explore),
    Search(SearchResults),
    Suggest { query: String, round: u64, terms: Vec<ytm::Suggestion> },
    /// An album or playlist; `more`: the rest of its songs follow in `CollectionMore`.
    Collection { load: u64, c: Collection, more: bool },
    /// The next page of a playlist sent as `Collection` with the same `load`.
    CollectionMore { id: String, load: u64, tracks: Vec<Track>, set_ids: Vec<Option<String>>, more: bool },
    Artist(ArtistPage),
    Library(Library),
    History(Vec<Track>),
    Uploads(Vec<Track>),
    Account { name: Option<String>, photo: Option<String> },
    Channels(Channels),
    /// A `Req::SwitchChannel` is done (requests go as `epoch` now), or `error` says why it isn't.
    SwitchedChannel { page_id: Option<String>, epoch: u64, error: Option<String> },
    ServerQueue(ytm::ServerQueue),
    /// Upload finished: how many files went up, and which failed.
    Uploaded { done: usize, failed: Vec<String> },
    Downloaded { title: String, path: PathBuf },
    /// A preliminary or final set for this request (only a final set may be empty).
    Lyrics { video_id: String, generation: u64, lyrics: LyricsSet, complete: bool },
    /// `None` means no matching Genius description or a lookup failure.
    GeniusAbout { video_id: String, description: Option<String> },
    AppleAlbumAbout { id: String, description: Option<String> },
    Segments { video_id: String, segments: Vec<crate::sponsorblock::Segment> },
    /// The curve, or `None` when youtube.com charts no replays for this video.
    BestPart { video_id: String, heat: Option<crate::bestpart::Heatmap> },
    /// YouTube's own word on whether AI made the video, from its description.
    AiLabel { video_id: String, ai: bool },
    /// Romanization/translation for one source's lines, arriving after them.
    LyricsExtras { video_id: String, source: String, target: String, extras: crate::translate::Extras },
    Art { key: String, art: Art },
    /// The same for a page's own cover, which nothing is playing.
    PageArt { key: String, art: Art },
    /// Apple's page for an artist, when there is one (`None`: no match, or no token).
    AppleArtist { id: String, info: Option<crate::apple::Artwork> },
    /// Apple's shelves for one of its browse pages; `path` is what the UI asked for
    /// (empty `shelves`: the page didn't answer).
    AppleFeed { path: String, shelves: Vec<crate::apple::Shelf> },
    /// Apple's own collection page (`None`: the page didn't answer).
    AppleCollection { url: String, collection: Option<crate::apple::Collection> },
    /// YouTube Music's copy of an Apple tile, as the target to open it as (`None`: none).
    AppleOpened { apple: Target, resolved: Option<Target> },
    /// Apple's motion sleeve for a release; `key` is what the UI asked it for.
    AppleCover { key: String, motion: Option<crate::apple::Motion> },
    /// The music-video player's picture for `key`'s song: `None` when YouTube Music has no clip of
    /// it, or the clip has no stream the decoder can take.
    MusicVideo { key: String, video: Option<innertube::Video> },
    /// Spotify's canvas for `key`'s song: its file's name and address, when there is one.
    Canvas { key: String, canvas: Option<(String, String)> },
    /// A signature for an artist, already whitened for the header.
    ArtistSignature { key: String, signature: Option<crate::artist_signature::Signature> },
    /// What a pasted hi-res source link really serves; `key` is what the UI asked with.
    /// Neither the summary nor the reason names the link, which carries a token.
    HiResSourceChecked { key: String, result: Result<String, String> },
    Radio { seed: String, tracks: Vec<Track> },
    /// Explore's moods, for Home's mood tile.
    Moods(Vec<ytm::Mood>),
    /// A mood's station: its name, and the queue its playlists make.
    MoodStation { name: String, tracks: Vec<Track> },
    /// What was asked to play (a `Req::PlayCollection`), and its songs.
    PlayQueue { target: Target, tracks: Vec<Track> },
    Liked { video_id: String, like: bool },
    /// A run of likes or unlikes: `taken` just went through, `done` of `total` tried.
    LikeProgress { taken: Vec<String>, done: usize, total: usize, like: bool },
    /// The songs YouTube Music took, and the ones it refused.
    LikedMany { video_ids: Vec<String>, failed: Vec<String>, like: bool },
    PlaylistCreated { id: String, songs: usize },
    PlaylistChanged { id: String, message: &'static str },
    Collaboration(ytm::Collaboration),
    /// Playback for `generation` failed before reaching the audio engine.
    PlayError { generation: u64, msg: String },
    /// What `generation` is playing from a hi-res source (codec, rate, depth, size).
    AudioInfo { generation: u64, info: crate::hires::Info },
    /// Whether `generation` is actively attempting to upgrade quality from hi-res addons.
    UpgradingQuality { generation: u64, active: bool },
    /// What `generation`'s decoder is being fed, whatever the source (stats for nerds).
    StreamStats { generation: u64, stats: stream::Stats },
    /// Play `generation` is the song version of the music video that was asked for
    /// (`None`: that song wouldn't start, and the music video plays after all).
    PlayingAs { generation: u64, listed: String, song: Option<Track> },
    LoggedIn(bool),
    /// A past search left the account's history; the list already shows it gone.
    SearchForgotten,
    Error(String),
}

impl Resp {
    /// An answer that belongs to the signed-in account and channel it was asked as.
    fn is_account_scoped(&self) -> bool {
        matches!(
            self,
            Resp::Home(_)
                | Resp::HomeMore { .. }
                | Resp::Moods(_)
                | Resp::MoodStation { .. }
                | Resp::QuickPicksMore { .. }
                | Resp::Suggest { .. }
                | Resp::Library(_)
                | Resp::History(_)
                | Resp::Uploads(_)
                | Resp::Account { .. }
                | Resp::Channels(_)
                | Resp::ServerQueue(_)
                | Resp::Liked { .. }
                | Resp::LikeProgress { .. }
                | Resp::LikedMany { .. }
        )
    }

    /// An album or playlist load that ends without more songs: also sent when it fails,
    /// so the page stops waiting for it.
    fn ended(id: String, load: u64) -> Self {
        Resp::CollectionMore { id, load, tracks: Vec::new(), set_ids: Vec::new(), more: false }
    }
}

/// Dev hook: hide the named sources from both preliminary and final responses.
fn prepare_lyrics_response(mut set: LyricsSet, fail: Option<&str>, final_set: bool) -> Option<LyricsSet> {
    if let Some(fail) = fail {
        set.sources.retain(|l| !fail.split(',').any(|k| k.trim() == l.provider.key()));
    }
    (final_set || !set.sources.is_empty()).then_some(set)
}

/// Complete an about request even if its handler panicked or was cancelled.
fn finish_genius_about(video_id: Option<String>, resp: Option<Resp>) -> Option<Resp> {
    match (video_id, resp) {
        (Some(_), answer @ Some(Resp::GeniusAbout { .. })) => answer,
        (Some(video_id), _) => Some(Resp::GeniusAbout { video_id, description: None }),
        (None, answer) => answer,
    }
}

/// Likes and unlikes go one after another, this far apart. YouTube Music answers faster
/// ones as taken and then drops many: on a test account 9 of 20 unlikes sent back to back
/// stayed liked, against 1 of 20 sent 400 ms apart; on a limited account 576 of 1,296
/// likes sent back to back were dropped, and liking those again took as long as pacing.
pub const LIKE_GAP: std::time::Duration = std::time::Duration::from_millis(400);

/// One run of many likes at a time (a selection here, or a Spotify transfer): run side by
/// side, one undoes the other (a transfer skips songs as liked that an unlike run then
/// takes out).
pub static LIKES: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

/// How long one like or unlike may take. Taken ones answer in about a quarter second;
/// ones YouTube Music refuses while it limits the account are held 8–9 s before the 403
/// (two of ten unlikes cost 17 of 27 s; in a transfer one like in six or so hangs).
/// Sending it again is harmless (liking a liked song changes nothing) and usually goes
/// straight through.
pub const LIKE_WAIT: std::time::Duration = std::time::Duration::from_millis(1500);

/// Like or unlike one song; whether YouTube Music took it. Refusals are retried by the
/// API (after its shared pause while the account is limited); one that hangs or fails is
/// sent again, up to three times in all.
async fn like_one(api: &ytmapi::Api, id: &str, like: bool) -> bool {
    for tries in 0..3 {
        match tokio::time::timeout(LIKE_WAIT, ytm::set_like(api, id, like)).await {
            Ok(Ok(())) => return true,
            Ok(Err(e)) => log::debug!("like={like} {id}: {e:#}"),
            // Not refused yet: again right away.
            Err(_) => {
                log::debug!("like={like} {id}: no answer in {LIKE_WAIT:?}; sending it again");
                continue;
            }
        }
        if tries < 2 {
            tokio::time::sleep(std::time::Duration::from_millis(500)).await;
        }
    }
    false
}

/// Like or unlike a selection, one at a time (paced, see `LIKE_GAP`), then check
/// Liked Music and try again what didn't take. `progress(taken, tried)` after each song.
/// Returns the ones taken and the ones refused; unlikes still listed once checking stops
/// getting anywhere count as refused, likes don't (songs that can't be played are liked but not listed).
/// One run at a time, transfers included (`LIKES`); `progress(None, 0)` while waiting its turn.
pub async fn like_many(api: &ytmapi::Api, ids: Vec<String>, like: bool, mut progress: impl FnMut(Option<&str>, usize)) -> (Vec<String>, Vec<String>) {
    let epoch = api.epoch();
    let _turn = match LIKES.try_lock() {
        Ok(turn) => turn,
        Err(_) => {
            progress(None, 0);
            LIKES.lock().await
        }
    };
    // A channel switch went first: these were picked in the other channel's lists.
    if api.epoch() != epoch {
        log::info!("likes: {} not sent, the account or channel changed while they waited", ids.len());
        return (Vec::new(), ids);
    }
    let total = ids.len();
    let mut failed = Vec::new();
    for (i, id) in ids.iter().enumerate() {
        let taken = like_one(api, id, like).await;
        if !taken {
            failed.push(id.clone());
        }
        progress(taken.then_some(id.as_str()), i + 1);
        tokio::time::sleep(LIKE_GAP).await;
    }
    // Check and try again while it gets anywhere: a throttled account takes a few rounds.
    let (mut before, mut stuck) = (usize::MAX, 0);
    for round in 0..10 {
        if total < 2 {
            break;
        }
        tokio::time::sleep(std::time::Duration::from_secs(2)).await;
        let listed: std::collections::HashSet<String> = match ytm::playlist(api, "LM", true, None).await {
            Ok(lm) => lm.tracks.into_iter().map(|t| t.id).collect(),
            Err(e) => {
                log::warn!("checking likes: {e:#}");
                break;
            }
        };
        let left: Vec<String> = ids.iter().filter(|id| listed.contains(*id) != like && !failed.contains(*id)).cloned().collect();
        log::debug!("like={like} check {round}: Liked Music lists {}, {} of {total} not taken yet", listed.len(), left.len());
        if left.is_empty() {
            break;
        }
        stuck = if left.len() < before { 0 } else { stuck + 1 };
        before = left.len();
        if stuck == 2 || round == 9 {
            if !like {
                failed.extend(left);
            }
            break;
        }
        // The second go is paced either way.
        for id in &left {
            like_one(api, id, like).await;
            tokio::time::sleep(LIKE_GAP).await;
        }
    }
    let done: Vec<String> = ids.into_iter().filter(|id| !failed.contains(id)).collect();
    (done, failed)
}

/// A video id and its stream buffer.
type StreamSlot = Arc<std::sync::Mutex<Option<(String, Arc<Shared>)>>>;
type SongCell = Arc<tokio::sync::OnceCell<Option<Track>>>;

/// How long a play waits for a music video's song version before playing the video.
const PLAY_SONG_WAIT: std::time::Duration = std::time::Duration::from_millis(2500);
/// A prefetch has until the song before it ends.
const PREFETCH_SONG_WAIT: std::time::Duration = std::time::Duration::from_secs(20);
/// How long playback waits for the hi-res sources before falling back to YouTube. A cold
/// addon mints a lossless URL in a few seconds, and every source is asked at once.
const HIRES_WAIT: std::time::Duration = std::time::Duration::from_secs(20);

/// How long a song's best part is waited for. It marks a button on the artwork, not the
/// music: an answer that misses the window leaves the song without one until it's asked
/// again, and that costs nothing.
const HEATMAP_WAIT: std::time::Duration = std::time::Duration::from_secs(8);

#[derive(Clone)]
pub struct Backend {
    rt: Arc<Runtime>,
    api: Arc<ytmapi::Api>,
    tx: Sender<Resp>,
    audio: AudioHandle,
    wake: Arc<dyn Fn() + Send + Sync>,
    data_dir: PathBuf,
    lyrics: Arc<lyrics::Client>,
    translate: Arc<crate::translate::Client>,
    /// The upcoming track, resolved and downloading ahead of time.
    prefetched: StreamSlot,
    /// The stream most recently started, kept so a replay of a fully downloaded song
    /// (repeat one, restart) doesn't download it again.
    current: StreamSlot,
    jsc: Arc<jsc::Solver>,
    /// Whether the signed-in account has Premium; checked once per sign-in. A failed
    /// check is retried no sooner than `PREMIUM_RETRY` later.
    premium: Arc<tokio::sync::Mutex<Result<bool, Option<std::time::Instant>>>>,
    /// High quality: with Premium, every song goes through the signed-in web player
    /// for its 256 kbps stream instead of the anonymous 128 kbps one.
    hq: Arc<std::sync::atomic::AtomicBool>,
    /// The listener's hi-res addons, in the order their links were given.
    hires: Arc<std::sync::RwLock<Vec<Arc<hires::Client>>>>,
    /// Ask the addons for Dolby Atmos renditions when they offer one.
    atmos: Arc<std::sync::atomic::AtomicBool>,
    /// Play YouTube first and upgrade to hi-res in the background.
    disable_direct: Arc<std::sync::atomic::AtomicBool>,
    /// Songs the listener sent back to YouTube audio: no addon copy until they leave.
    reverted: Arc<std::sync::Mutex<std::collections::HashSet<String>>>,
    /// Song versions of music videos looked up this session (`None`: there's none), by
    /// video and whether the account has Premium (which gets YouTube's own pairs). One
    /// cell each, so a prefetch and the play of the same video share a lookup.
    songs: Arc<std::sync::Mutex<std::collections::HashMap<String, SongCell>>>,
    /// The music video found for a song this session, by song id. A search that goes
    /// quiet later — throttled, or answered as a bot — mustn't take the picture away from
    /// a song that had one found for it before.
    videos: Arc<std::sync::Mutex<std::collections::HashMap<String, String>>>,
}

impl Backend {
    pub fn new(
        storage: PathBuf,
        tx: Sender<Resp>,
        audio: AudioHandle,
        wake: Arc<dyn Fn() + Send + Sync>,
    ) -> anyhow::Result<Self> {
        let rt = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .thread_name("net")
            .enable_all()
            .build()?;
        std::fs::create_dir_all(&storage)?;
        let data_dir = storage;
        let http = crate::proxy::http();
        let lyrics = Arc::new(lyrics::Client::new(http.clone(), &data_dir));
        let translate = Arc::new(crate::translate::Client::new(http, &data_dir));
        let jsc = Arc::new(jsc::Solver::new(&data_dir));
        let api = Arc::new(ytmapi::Api::new(&data_dir));
        if crate::proxy::needs_relay()
            && let Err(e) = rt.block_on(crate::proxy::start_relay())
        {
            log::warn!("proxy relay: {e:#}");
        }
        let backend = Self { rt: Arc::new(rt), api, tx, audio, wake, prefetched: Default::default(), current: Default::default(), data_dir, lyrics, translate, jsc, premium: Arc::new(tokio::sync::Mutex::new(Err(None))), hq: Default::default(), hires: Default::default(), atmos: Default::default(), disable_direct: Default::default(), reverted: Default::default(), songs: Default::default(), videos: Default::default() };
        backend.keep_signed_in();
        Ok(backend)
    }

    /// Refresh the session's cookies every few minutes, as an open YouTube tab does:
    /// Google signs out a copy that stops taking new ones.
    fn keep_signed_in(&self) {
        const EVERY: std::time::Duration = std::time::Duration::from_secs(10 * 60);
        let this = self.clone();
        self.rt.spawn(async move {
            loop {
                if this.api.account().is_some() {
                    this.api.ensure_visitor().await;
                    match this.api.rotate().await {
                        Ok(()) => log::debug!("session cookies refreshed"),
                        Err(e) if e.is::<webmusic::Revoked>() => this.check_session().await,
                        Err(e) => log::info!("refreshing session cookies failed: {e:#}"),
                    }
                }
                tokio::time::sleep(EVERY).await;
            }
        });
    }

    /// Something suggested Google signed the session out. When YouTube confirms it no
    /// longer knows the session, sign out here too and say so, rather than every
    /// signed-in page failing on its own.
    async fn check_session(&self) {
        // Several requests answered at once ask together; one check is enough.
        static CHECKING: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());
        let _one = CHECKING.lock().await;
        if self.api.account().is_none() {
            return;
        }
        // Signing out deletes the session, so only once youtube.com shows it signed out
        // twice, a minute apart (each after a rotation, which can bring it back). One
        // signed-out answer can be a hiccup (throttling, a consent or "unusual traffic"
        // page), and a refused rotation alone isn't proof either: the clients whose
        // sessions last never sign out on their own.
        for attempt in 0..2 {
            if let Err(e) = self.api.rotate().await {
                log::info!("rotating cookies while checking the session: {e:#}");
            }
            let Some(account) = self.api.account() else { return };
            match self.api.session_from_cookie(&account.cookie).await {
                Ok(_) => return,
                Err(e) if e.is::<ytmapi::NotSignedIn>() => {
                    log::warn!("signed-in session looks signed out ({}): {e:#}", if attempt == 0 { "checking again in a minute" } else { "twice" });
                    if attempt == 0 {
                        tokio::time::sleep(std::time::Duration::from_secs(60)).await;
                    }
                }
                // Offline, throttled or similar: nothing learned.
                Err(e) => {
                    log::info!("couldn't check the session: {e:#}");
                    return;
                }
            }
        }
        log::warn!("signed-in session no longer valid");
        self.forget_session().await;
        let _ = self.tx.send(Resp::LoggedIn(false));
        let _ = self.tx.send(Resp::Error("Your YouTube sign-in expired. Sign in again to get your library back".into()));
        self.wake();
    }

    /// Act as another of the account's channels. Not while likes of a selection or a
    /// transfer are running: they'd go on as the new channel.
    async fn switch_channel(&self, page_id: Option<String>, epoch: u64) -> anyhow::Result<u64> {
        let _likes = LIKES.try_lock().map_err(|_| anyhow::anyhow!("Wait until the likes going through are done"))?;
        // A Premium check running now is for the old channel: let it finish, then forget it.
        let mut premium = self.premium.lock().await;
        let epoch = self.api.switch_channel(page_id, epoch)?;
        *premium = Err(None);
        drop(premium);
        self.warm_signed_in();
        log::info!("switched channel");
        Ok(epoch)
    }

    async fn forget_session(&self) {
        self.api.sign_out();
        *self.premium.lock().await = Err(None);
        let profile = self.login_profile();
        let _ = tokio::task::spawn_blocking(move || crate::login::forget(&profile)).await;
    }

    pub fn api(&self) -> Arc<ytmapi::Api> {
        self.api.clone()
    }

    /// The shared client (see `proxy::http`).
    pub fn http(&self) -> reqwest::Client {
        crate::proxy::http()
    }

    pub fn spawn<F: Future<Output = ()> + Send + 'static>(&self, f: F) {
        self.rt.spawn(f);
    }

    pub fn spawn_handle<F: Future<Output = ()> + Send + 'static>(&self, f: F) -> tokio::task::JoinHandle<()> {
        self.rt.spawn(f)
    }

    pub fn wake(&self) {
        (self.wake)()
    }

    pub fn request(&self, req: Req) {
        let (what, quiet) = (req.name(), req.quiet());
        let play_gen = match &req {
            Req::Play { generation, .. } => Some(*generation),
            _ => None,
        };
        let collection = match &req {
            Req::Album { id, load } | Req::Playlist { id, load, .. } => Some((id.clone(), *load)),
            _ => None,
        };
        let about_id = match &req {
            Req::GeniusAbout(track) => Some(track.id.clone()),
            _ => None,
        };
        let album_about_id = match &req {
            Req::AppleAlbumAbout { id, .. } => Some(id.clone()),
            _ => None,
        };
        let lyrics_ticket = match &req {
            Req::Lyrics { track, generation, .. } => Some(self.lyrics.begin_fetch(&track.id, *generation)),
            _ => None,
        };
        let this = self.clone();
        let t0 = std::time::Instant::now();
        let epoch = self.api.epoch();
        let task = self.rt.spawn(async move {
            let r = this.handle(req, lyrics_ticket).await;
            log::debug!("{what}: done in {:?}", t0.elapsed());
            r
        });
        let this = self.clone();
        self.rt.spawn(async move {
            // A panic in a handler (or a library it calls) fails just this request,
            // reported like any other error.
            let resp = match task.await {
                Ok(resp) => resp,
                Err(e) if e.is_panic() => {
                    log::error!("{what}: request panicked");
                    match play_gen {
                        Some(generation) => Some(Resp::PlayError { generation, msg: "YouTube didn't respond properly".into() }),
                        None => (!quiet).then(|| Resp::Error(format!("{what} failed: YouTube didn't respond properly"))),
                    }
                }
                Err(_) => None,
            };
            let mut resp = finish_genius_about(about_id, resp);
            if let Some(id) = album_about_id
                && !matches!(resp, Some(Resp::AppleAlbumAbout { .. }))
            {
                resp = Some(Resp::AppleAlbumAbout { id, description: None });
            }
            // An album or playlist load that failed ends too, so its page stops waiting.
            if let Some((id, load)) = collection
                && !matches!(resp, Some(Resp::Collection { .. } | Resp::CollectionMore { .. }))
            {
                let _ = this.tx.send(Resp::ended(id, load));
            }
            // Asked as another sign-in or channel than the one now used: it isn't this one's.
            let resp = resp.filter(|r| {
                let stale = this.api.epoch() != epoch && r.is_account_scoped();
                if stale {
                    log::debug!("{what}: answer for the previous account or channel dropped");
                }
                !stale
            });
            if let Some(resp) = resp {
                let _ = this.tx.send(resp);
                this.wake();
            }
            if this.api.take_signed_out() {
                this.check_session().await;
            }
        });
    }

    /// A sleeve as a 64 px blur: fetched near that size, never the 544 px art.
    async fn blur(&self, url: String) -> anyhow::Result<Art> {
        let url = model::sized(&url, 2 * crate::art::SIZE);
        let bytes = self.http().get(&url).send().await?.error_for_status()?.bytes().await?;
        Ok(tokio::task::spawn_blocking(move || crate::art::process(&bytes)).await??)
    }

    async fn handle(&self, req: Req, lyrics_ticket: Option<lyrics::FetchTicket>) -> Option<Resp> {
        let api = &*self.api;
        // Personalised pages ask as the account when signed in, like music.youtube.com.
        let me = self.is_logged_in();
        let (what, quiet) = (req.name(), req.quiet());
        let res: anyhow::Result<Option<Resp>> = async {
            Ok(Some(match req {
                Req::Home(params) => Resp::Home(ytm::home(api, params.as_deref(), me).await?),
                Req::HomeMore(token) => {
                    let page = ytm::home_more(api, &token, me).await?;
                    Resp::HomeMore { token, page }
                }
                Req::Moods => Resp::Moods(ytm::moods(api, me).await?),
                Req::MoodStation(mood) => {
                    let tracks = ytm::mood_station(api, &mood, me).await?;
                    Resp::MoodStation { name: mood.name, tracks }
                }
                Req::MoreQuickPicks(seed) => {
                    let tracks = ytm::radio(api, &seed, me, 0).await?;
                    Resp::QuickPicksMore { seed, tracks }
                }
                Req::Explore(preferred_artists) => self.explore(&preferred_artists, me).await?,
                Req::Search(query) => self.search(query, me).await?,
                Req::Suggest { query, round } => {
                    let terms = ytm::suggestions(api, &query, me).await?.into_iter().take(8).collect();
                    Resp::Suggest { query, round, terms }
                }
                Req::ForgetSearch(token) => {
                    ytm::forget_search(api, &token).await?;
                    Resp::SearchForgotten
                }
                Req::Album { id, load } => Resp::Collection { load, c: ytm::album(api, &id).await?, more: false },
                Req::Playlist { id, load, stream: false } => Resp::Collection { load, c: ytm::playlist(api, &id, me, None).await?, more: false },
                Req::Playlist { id, load, stream: true } => self.stream_playlist(id, load, me).await?,
                Req::Artist(id) => Resp::Artist(ytm::artist(api, &id).await?),
                Req::Library => self.library().await?,
                Req::History => Resp::History(ytm::history(api).await?),
                Req::Uploads => Resp::Uploads(ytm::uploads(api).await?),
                Req::Account => {
                    let (name, photo) = ytm::account(api).await?;
                    Resp::Account { name, photo }
                }
                Req::Channels => {
                    let epoch = api.epoch();
                    let list = ytm::channels(api).await?;
                    Resp::Channels(Channels { list, current: api.account().and_then(|a| a.channel().map(str::to_owned)), epoch })
                }
                Req::SwitchChannel { page_id, epoch } => match self.switch_channel(page_id.clone(), epoch).await {
                    Ok(epoch) => Resp::SwitchedChannel { page_id, epoch, error: None },
                    Err(e) => {
                        log::warn!("switching channel failed: {e:#}");
                        Resp::SwitchedChannel { page_id, epoch, error: Some(e.to_string()) }
                    }
                },
                Req::ServerQueue => match ytm::server_queue(api).await? {
                    Some(q) => Resp::ServerQueue(q),
                    None => return Ok(None),
                },
                Req::Upload(files) => self.upload(&files).await?,
                Req::Lyrics { track, generation, genius_enabled } => {
                    let video_id = track.id.clone();
                    let ticket = lyrics_ticket.as_ref().expect("lyrics request registered");
                    Resp::Lyrics { lyrics: self.lyrics_for(&track, generation, ticket, genius_enabled).await, video_id, generation, complete: true }
                }
                Req::GeniusAbout(track) => {
                    let artist = track.artist_line();
                    let query = lyrics::Query {
                        video_id: &track.id,
                        song: &track.title,
                        artist: &artist,
                        album: track.album.as_ref().map(|a| a.name.as_str()),
                        duration: track.duration,
                    };
                    let description = self.lyrics.genius_about(&query).await.unwrap_or_else(|e| {
                        log::info!("genius about: {e:#}");
                        None
                    });
                    Resp::GeniusAbout { video_id: track.id, description }
                }
                Req::AppleAlbumAbout { id, title, artist } => {
                    let description = crate::apple::album_description(&self.http(), &title, &artist).await;
                    Resp::AppleAlbumAbout { id, description }
                }
                Req::Segments { video_id } => {
                    let segments = crate::sponsorblock::segments(&self.http(), &video_id).await?;
                    Resp::Segments { video_id, segments }
                }
                Req::BestPart(video_id) => {
                    let heat = self.replay_curve(&video_id).await;
                    Resp::BestPart { video_id, heat }
                }
                Req::AiCheck { video_id } => {
                    let vd = self.api.visitor_data(false).await?;
                    let ai = crate::innertube::made_with_ai(&self.http(), &video_id, &vd).await?;
                    Resp::AiLabel { video_id, ai }
                }
                Req::LyricsExtras { video_id, source, lines, lang, target } => {
                    let key = format!("{video_id}_{source}");
                    let Some(extras) = self.translate.extras(&key, &lines, lang.as_deref(), &target).await else { return Ok(None) };
                    Resp::LyricsExtras { video_id, source, target, extras }
                }
                Req::Art { key, url } => Resp::Art { key, art: self.blur(url).await? },
                Req::PageArt { key, url } => Resp::PageArt { key, art: self.blur(url).await? },
                Req::AppleArtist { id, name } => {
                    let info = crate::apple::artist(&self.http(), &name).await;
                    log::info!("apple artist '{name}': {}", match &info {
                        Some(a) => match &a.logo {
                            Some(l) => format!("'{}' wordmark {}x{}", a.name, l.w, l.h),
                            None => format!("'{}' in type (no wordmark)", a.name),
                        },
                        None => "no answer".to_owned(),
                    });
                    Resp::AppleArtist { id, info }
                }
                Req::AppleFeed(path) => {
                    let shelves = crate::apple::shelves(&self.http(), &path).await.unwrap_or_default();
                    log::debug!("apple '{}': {} shelves", path, shelves.len());
                    Resp::AppleFeed { path, shelves }
                }
                Req::AppleCollection { url } => {
                    let collection = crate::apple::collection(&self.http(), &url).await.ok();
                    match &collection {
                        Some(c) => log::debug!("apple collection '{}': {} songs", c.title, c.songs.len()),
                        None => log::debug!("apple collection: no answer for the page"),
                    }
                    Resp::AppleCollection { url, collection }
                }
                Req::AppleSongs { target, songs } => {
                    // Every song is looked for on its own: a name Apple gives may belong
                    // to a copy YouTube Music doesn't have, and the rest still play.
                    let mut tracks = Vec::with_capacity(songs.len());
                    for s in &songs {
                        match self.find_song(&s.title, &s.artist, me).await {
                            Ok(t) => tracks.push(t),
                            Err(e) => log::debug!("apple song '{}': {e:#}", s.title),
                        }
                    }
                    Resp::PlayQueue { target, tracks }
                }
                Req::AppleLookup(apple) => {
                    let name = match &apple {
                        Target::Apple { title, artist, .. } => format!("{title} ({artist})"),
                        t => format!("{t:?}"),
                    };
                    let resolved = match self.apple_target(&apple, me).await {
                        Ok(t) => t,
                        Err(e) => {
                            log::debug!("apple lookup '{name}': {e:#}");
                            None
                        }
                    };
                    Resp::AppleOpened { apple, resolved }
                }
                Req::AppleCover { key, album, artist, title, record } => {
                    let motion = match (record.as_deref(), title.as_deref()) {
                        (Some(id), _) => crate::apple::motion_by_id(&self.http(), id).await,
                        (None, Some(t)) => crate::apple::song_motion(&self.http(), t, &artist, Some(&album)).await,
                        (None, None) => crate::apple::album_motion(&self.http(), &album, &artist).await,
                    };
                    if motion.is_none() {
                        log::debug!("apple: no motion sleeve for '{album}' by '{artist}'");
                    }
                    Resp::AppleCover { key, motion }
                }
                Req::MusicVideo { key, track, width, skip } => {
                    // A picture YouTube Music could have but didn't answer for is asked
                    // for again shortly: a search that comes back empty because the
                    // listener's other traffic has it throttled is not the song having no
                    // video, and the second try usually finds what the first lost.
                    let mut video = self.music_video(&track, width, me, skip).await.map_err(|e| {
                        log::info!("music video for '{}': {e:#}", track.title);
                        e
                    }).ok();
                    if video.is_none() {
                        tokio::time::sleep(std::time::Duration::from_secs(4)).await;
                        video = self.music_video(&track, width, me, skip).await.ok();
                    }
                    Resp::MusicVideo { key, video }
                }
                Req::ArtistSignature { key, endpoint, name } => {
                    let signature = crate::artist_signature::lookup(&self.http(), &endpoint, &name).await;
                    log::info!("artist signature: {}", match &signature {
                        Some(s) => format!("found one for '{name}' ({}x{})", s.width, s.height),
                        None => format!("none for '{name}'"),
                    });
                    Resp::ArtistSignature { key, signature }
                }
                Req::CheckHiResSource { key, link } => {
                    let host = hires::Client::new(&link).map_or_else(|| "?".to_owned(), |c| c.host());
                    let result = hires::check(&self.http(), &link).await;
                    match &result {
                        Ok(summary) => log::info!("hi-res source {host}: {summary}"),
                        Err(e) => log::warn!("hi-res source {host}: unusable: {e:#}"),
                    }
                    Resp::HiResSourceChecked { key, result: result.map_err(|e| e.to_string()) }
                }
                Req::Canvas { key, artist, title, ms } => {
                    // A song Spotify has no clip of, or an app never signed in to Spotify:
                    // no canvas, and the sleeve keeps its art.
                    let canvas = crate::transfer::canvas(&artist, &title, ms).await.map(|c| (c.name, c.url));
                    Resp::Canvas { key, canvas }
                }
                Req::Radio { seed, song_of } => {                    // A music video's radio is music videos; its song's is songs, as from the
                    // song itself. The lookup is shared with its play's (one per video).
                    let song = self.song_version(&seed, song_of.as_ref(), PREFETCH_SONG_WAIT).await;
                    let from = song.as_ref().map_or(&seed, |s| &s.id);
                    let mut tracks = ytm::radio(api, from, false, 50).await?;
                    // The radio starts with its seed, which is playing already.
                    tracks.retain(|t| t.id != *from);
                    Resp::Radio { seed, tracks }
                }
                Req::PlayCollection { target } => {
                    let tracks = match &target {
                        Target::Album(id) => ytm::album(api, id).await?.tracks,
                        Target::Playlist(id) => ytm::playlist(api, id, me, None).await?.tracks,
                        Target::Artist(id) => ytm::artist(api, id).await?.top,
                        Target::Song(t) => vec![t.clone()],
                        Target::Apple { kind, title, artist, .. } => self.apple_tracks(*kind, title, artist, me).await?,
                    };
                    Resp::PlayQueue { target, tracks }
                }
                Req::Download { track: t, for_video } => {
                    let path = self.download(&t, for_video).await?;
                    Resp::Downloaded { title: t.title, path }
                }
                Req::Play { video_id, generation, at, report, song_of, song, track } => match self.start_playback(&video_id, song_of.as_ref(), song, track.as_ref(), generation, at, report).await {
                    Ok(()) => return Ok(None),
                    Err(e) => Resp::PlayError { generation, msg: format!("{e:#}") },
                },
                Req::Prefetch { video_id, song_of, track } => {
                    self.prefetch(video_id, song_of, track).await?;
                    return Ok(None);
                }
                Req::Like { video_id, like } => {
                    ytm::set_like(api, &video_id, like).await?;
                    Resp::Liked { video_id, like }
                }
                Req::LikeMany { video_ids, like } => self.like_many(video_ids, like).await?,
                Req::Dislike(video_id) => {
                    ytm::dislike(api, &video_id).await?;
                    Resp::Liked { video_id, like: false }
                }
                Req::CreatePlaylist { title, video_ids } => {
                    let id = match video_ids.as_slice() {
                        [] => ytm::create_playlist(api, &title, None).await?,
                        [one] => ytm::create_playlist(api, &title, Some(one)).await?,
                        many => ytm::create_playlist_with(api, &title, many).await?,
                    };
                    Resp::PlaylistCreated { id, songs: video_ids.len() }
                }
                Req::EditPlaylist { id, title, description, privacy } => {
                    ytm::edit_playlist(api, &id, &title, &description, privacy.as_deref()).await?;
                    Resp::PlaylistChanged { id, message: "Playlist updated" }
                }
                Req::AddToPlaylist { playlist_id, video_ids } => {
                    ytm::add_videos(api, &playlist_id, &video_ids).await?;
                    Resp::PlaylistChanged { id: playlist_id, message: "Added to playlist" }
                }
                Req::RemoveFromPlaylist { playlist_id, items } => {
                    ytm::remove_videos(api, &playlist_id, &items).await?;
                    Resp::PlaylistChanged { id: playlist_id, message: "Removed from playlist" }
                }
                Req::DeletePlaylist(id) => {
                    ytm::delete_playlist(api, &id).await?;
                    Resp::PlaylistChanged { id, message: "Playlist deleted" }
                }
                Req::Collaboration(id) => Resp::Collaboration(ytm::collaboration(api, &id).await?),
                Req::SetCollaboration { info, change } => {
                    ytm::set_collaboration(api, &info, change).await?;
                    Resp::Collaboration(ytm::collaboration(api, &info.playlist_id).await?)
                }
                Req::SaveCollection { id, save } => {
                    ytm::save_collection(api, &id, save).await?;
                    Resp::PlaylistChanged { id, message: if save { "Saved to library" } else { "Removed from library" } }
                }
                Req::SetCookie(input) => {
                    self.set_cookie(&input).await?;
                    *self.premium.lock().await = Err(None);
                    self.warm_signed_in();
                    log::info!("signed in");
                    Resp::LoggedIn(true)
                }
                Req::Logout => {
                    self.forget_session().await;
                    Resp::LoggedIn(false)
                }
            }))
        }
        .await;
        res.unwrap_or_else(|e| {
            log::warn!("{what} failed: {e:#}");
            (!quiet).then(|| Resp::Error(format!("{what} failed: {e}")))
        })
    }

    /// Explore: the charts, and new albums by charting artists or the listener's own.
    async fn explore(&self, preferred_artists: &[String], me: bool) -> anyhow::Result<Resp> {
        let api = &*self.api;
        let (charts, new) = tokio::join!(ytm::charts(api), ytm::new_albums(api, me));
        let charts = charts?;
        // The charts page answers with its videos, genres and artists but stopped carrying
        // its ranked songs shelf, so the hot list is read out of the chart playlist it still
        // names as trending. A page that names none, or a playlist that will not open,
        // leaves the row out rather than filling it with a guess.
        let mut top = charts.top;
        let trending = charts.playlists.iter().find_map(|c| {
            let hot = {
                let t = c.title.to_lowercase();
                t.contains("trending") || t.contains("top songs")
            };
            match (&c.target, hot) {
                (Target::Playlist(id), true) => Some(id.clone()),
                _ => None,
            }
        });
        if top.is_empty()
            && let Some(id) = trending
            && let Ok(pl) = ytm::playlist(api, &id, false, Some(20)).await
        {
            top = pl.tracks;
        }
        Ok(Resp::Explore(Explore {
            new_albums: popular_new_albums(&new.unwrap_or_default(), &charts.artists, preferred_artists),
            charts: charts.playlists,
            top,
        }))
    }

    /// Songs, videos, podcast episodes, albums, artists and playlists for a search,
    /// asked at once. Only the songs must arrive.
    async fn search(&self, query: String, me: bool) -> anyhow::Result<Resp> {
        let api = &*self.api;
        let (t, v, ep, al, ar, pl) = tokio::join!(
            ytm::search_songs(api, &query, me),
            ytm::search_tracks(api, &query, ytm::Filter::Videos, me),
            ytm::search_tracks(api, &query, ytm::Filter::Episodes, me),
            ytm::search_cards(api, &query, ytm::Filter::Albums, me),
            ytm::search_cards(api, &query, ytm::Filter::Artists, me),
            ytm::search_cards(api, &query, ytm::Filter::Playlists, me),
        );
        // Songs, videos and episodes, each already in YouTube's own relevance order,
        // woven together: a video or a podcast episode earns its place among the songs
        // instead of waiting below all of them.
        let tracks = weave(vec![t?, v.unwrap_or_default(), ep.unwrap_or_default()]);
        Ok(Resp::Search(SearchResults {
            tracks,
            albums: al.unwrap_or_default(),
            artists: ar.unwrap_or_default(),
            playlists: pl.unwrap_or_default(),
            query,
        }))
    }

    /// YouTube Music's copy of a video Apple has: the clip is Apple's, the sound has to
    /// come from Google. Apple's own title breaks the tie between the video hits, since
    /// YouTube's order is the only ranking worth trusting over it. `mine` accepts nothing
    /// but the artist's own clip — someone else's cover or a fan channel's lyric video is
    /// no picture for the song, and counts as missing rather than as a hit.
    async fn find_video(&self, artist: &str, title: &str, me: bool, mine: bool) -> anyhow::Result<Track> {
        let query = format!("{title} {artist}");
        let hits = ytm::search_tracks(&*self.api, &query, ytm::Filter::Videos, me).await?;
        let want = title.to_lowercase();
        let ours = |t: &Track| !mine || near_artist(artist, &t.artist_line());
        let named = hits.iter().find(|t| t.music_video && ours(t) && t.title.to_lowercase().contains(&want)).cloned();
        let official = hits.iter().find(|t| t.music_video && ours(t)).cloned();
        let found = named.or(official).or_else(|| hits.into_iter().find(|t| ours(t)));
        found.ok_or_else(|| anyhow::anyhow!("YouTube Music has no copy of {title}"))
    }

    /// The clip YouTube Music holds for a song that is not itself a video: the video
    /// version paired with the song on its own page first, then a search of the song and
    /// its artist, then one naming the official video — YouTube Music's own copy before
    /// anything else is trusted with the picture.
    async fn video_for(&self, track: &Track, me: bool) -> anyhow::Result<Track> {
        // Only the song's own artist's clip — but leniently: a video that names none of
        // the song's artists is someone else's, while one that names any of them is the
        // song's own (features, remixers and all).
        let wanted: Vec<String> = track.artists.iter().map(|a| crate::apple::norm(&a.name)).filter(|n| !n.is_empty()).collect();
        let ours = |t: &Track| {
            let has: Vec<String> = t.artists.iter().map(|a| crate::apple::norm(&a.name)).collect();
            has.is_empty() || wanted.iter().any(|w| has.iter().any(|h| h == w || h.contains(w.as_str()) || w.contains(h.as_str())))
        };
        if let Ok(Some(paired)) = ytm::paired_video(&self.api, &track.id).await
            && ours(&paired)
        {
            return Ok(paired);
        }
        match self.find_video(&track.artist_line(), &track.title, me, true).await {
            Ok(t) => Ok(t),
            Err(e) => {
                log::info!("music video for '{}': {e:#}; asking for the official video", track.title);
                let query = format!("{} official music video", track.title);
                let hits = ytm::search_tracks(&*self.api, &query, ytm::Filter::Videos, me).await?;
                let want = track.title.to_lowercase();
                hits.into_iter()
                    .find(|t| t.music_video && t.title.to_lowercase().contains(&want) && ours(t))
                    .ok_or_else(|| anyhow::anyhow!("YouTube Music has no music video of {}", track.title))
            }
        }
    }

    /// The music-video player's picture for a song: the music video YouTube Music has of it — the
    /// song's own id when it already is one, its paired video version next, and only ever
    /// the same artist's clip — and the video-only stream to decode from it, which carries
    /// no sound, so the song keeps playing underneath. With `skip`, the parts the
    /// SponsorBlock community marked as not the music come back with it, so the clip can
    /// be started where the song actually begins inside it.
    async fn music_video(&self, track: &Track, width: u32, me: bool, skip: bool) -> anyhow::Result<innertube::Video> {
        let id = self.video_id(track, me).await?;
        let vd = self.api.visitor_data(false).await?;
        let mut v = match innertube::video_stream(&self.http(), &id, &vd, width).await {
            Ok(v) => v,
            // A clip the anonymous client is refused is one the listener's own session
            // may well be allowed: YouTube Music already knows them.
            Err(e) if needs_account(&e) => {
                log::info!("video {id}: the anonymous client is refused ({e:#}); asking as the account");
                innertube::video_stream_signed(&self.api, &id, width).await?
            }
            Err(e) => {
                log::info!("visionOS picture: {e:#}; retrying with new visitor data");
                let vd = self.api.visitor_data(true).await?;
                innertube::video_stream(&self.http(), &id, &vd, width).await?
            }
        };
        // A song's video usually runs ahead of the song itself — a title card, an
        // interview, a skit. The marks say how far, and the picture starts from there
        // rather than from the clip's top.
        if skip {
            match crate::sponsorblock::segments(&self.http(), &v.id).await {
                Ok(segs) => {
                    v.skip = segs.into_iter().filter(|s| s.fits(v.duration_s)).collect();
                    if !v.skip.is_empty() {
                        log::info!("sponsorblock: {} mark(s) on the clip {}", v.skip.len(), v.id);
                    }
                }
                Err(e) => log::debug!("sponsorblock marks for the clip {id}: {e:#}"),
            }
        }
        Ok(v)
    }

    /// The video YouTube Music holds for a song — and the one it held the last time the
    /// song was asked about. A lookup that fails now mustn't leave a song whose clip was
    /// already found without a picture.
    async fn video_id(&self, track: &Track, me: bool) -> anyhow::Result<String> {
        if track.music_video {
            return Ok(track.id.clone());
        }
        let known = self.videos.lock().unwrap().get(&track.id).cloned();
        if let Some(id) = known {
            return Ok(id);
        }
        let id = self.video_for(track, me).await?.id;
        self.videos.lock().unwrap().insert(track.id.clone(), id.clone());
        Ok(id)
    }

    /// What plays when an Apple tile is asked for as a queue: the songs YouTube Music
    /// has of the release Apple names.
    async fn apple_tracks(&self, kind: model::AppleKind, title: &str, artist: &str, me: bool) -> anyhow::Result<Vec<Track>> {
        use model::AppleKind as K;
        Ok(match kind {
            K::Video => vec![self.find_video(artist, title, me, false).await?],
            K::Song => vec![self.find_song(title, artist, me).await?],
            K::Album => ytm::album(&*self.api, &self.find_release(title, artist, false, me).await?).await?.tracks,
            K::Playlist => ytm::playlist(&*self.api, &self.find_release(title, artist, true, me).await?, me, None).await?.tracks,
            // Apple's live radio is Apple's own stream; Google has nothing like it.
            K::Radio => return Err(anyhow::anyhow!("Apple's live radio doesn't play here — it's Apple's own stream")),
        })
    }

    /// YouTube Music's copy of an Apple tile, as the target to open it as. Apple's ids
    /// mean nothing to Google, so its name and artist do the looking up.
    async fn apple_target(&self, target: &Target, me: bool) -> anyhow::Result<Option<Target>> {
        let Target::Apple { kind, title, artist, .. } = target else { return Ok(None) };
        use model::AppleKind as K;
        let found = match kind {
            K::Album => Some(Target::Album(self.find_release(title, artist, false, me).await?)),
            K::Playlist => Some(Target::Playlist(self.find_release(title, artist, true, me).await?)),
            K::Song => Some(Target::Song(self.find_song(title, artist, me).await?)),
            K::Video => Some(Target::Song(self.find_video(artist, title, me, false).await?)),
            K::Radio => None,
        };
        Ok(found)
    }

    /// YouTube Music's copy of a song Apple names, in Google's own order: the hit with
    /// both Apple's title and its artist, else its title, else whatever it ranks first.
    async fn find_song(&self, title: &str, artist: &str, me: bool) -> anyhow::Result<Track> {
        let hits = ytm::search_tracks(&*self.api, &format!("{title} {artist}"), ytm::Filter::Songs, me).await?;
        let named = hits.iter().find(|t| same_name(&t.title, title) && near_artist(artist, &t.artist_line())).cloned();
        let titled = named.or_else(|| hits.iter().find(|t| same_name(&t.title, title)).cloned());
        titled.or_else(|| hits.first().cloned()).ok_or_else(|| anyhow::anyhow!("YouTube Music has no copy of {title}"))
    }

    /// YouTube Music's id for a release Apple names. Apple's playlists are curated under
    /// Apple's own name, so only their titles are worth searching for.
    async fn find_release(&self, title: &str, artist: &str, playlist: bool, me: bool) -> anyhow::Result<String> {
        let filter = if playlist { ytm::Filter::Playlists } else { ytm::Filter::Albums };
        let query = if playlist || artist.trim().is_empty() { title.to_owned() } else { format!("{title} {artist}") };
        let hits = ytm::search_cards(&*self.api, &query, filter, me).await?;
        let pick = |card: &Card| match &card.target {
            Target::Album(id) | Target::Playlist(id) => Some(id.clone()),
            _ => None,
        };
        let named = hits.iter().find(|c| same_name(&c.title, title) && (playlist || near_artist(artist, &c.subtitle))).and_then(pick);
        let titled = named.or_else(|| hits.iter().find(|c| same_name(&c.title, title)).and_then(pick));
        titled.or_else(|| hits.first().and_then(pick)).ok_or_else(|| anyhow::anyhow!("YouTube Music has no copy of {title}"))
    }

    /// Saved playlists and albums.
    async fn library(&self) -> anyhow::Result<Resp> {
        let api = &*self.api;
        // Liked songs are Liked Music, loaded like any playlist. Each half shows
        // without the other; it only fails when both do.
        let (pls, albums) = tokio::join!(ytm::saved_playlists(api), ytm::saved_albums(api));
        let pls = match (pls, &albums) {
            (Err(e), Err(_)) => return Err(e),
            (pls, _) => pls,
        };
        if let Err(e) = &pls {
            log::warn!("saved playlists didn't load: {e:#}");
        }
        if let Err(e) = &albums {
            log::warn!("saved albums didn't load: {e:#}");
        }
        Ok(Resp::Library(Library {
            playlists_failed: pls.is_err(),
            albums_failed: albums.is_err(),
            playlists: pls.map(|p| p.into_iter().filter(saved_playlist_visible).collect()).unwrap_or_default(),
            albums: albums.unwrap_or_default(),
        }))
    }

    /// Upload songs, then refresh the uploads while YouTube Music processes them.
    async fn upload(&self, files: &[PathBuf]) -> anyhow::Result<Resp> {
        let api = &*self.api;
        let session = api.account().ok_or_else(|| anyhow::anyhow!("sign in to upload music"))?;
        let (mut done, mut failed) = (0, Vec::new());
        for f in files {
            let name = f.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
            match session.upload(&self.http(), f).await {
                Ok(()) => done += 1,
                Err(e) => {
                    log::warn!("upload {name}: {e:#}");
                    failed.push(name);
                }
            }
        }
        if done > 0 {
            // YouTube Music needs a little while to process new uploads.
            let this = self.clone();
            self.rt.spawn(async move {
                for wait in [20, 40, 60] {
                    tokio::time::sleep(std::time::Duration::from_secs(wait)).await;
                    if let Ok(t) = ytm::uploads(&this.api).await {
                        let _ = this.tx.send(Resp::Uploads(t));
                        this.wake();
                    }
                }
            });
        }
        Ok(Resp::Uploaded { done, failed })
    }

    /// Open the next song's stream ahead of time, once the playing one has downloaded.
    /// `song_of`: the music video it stands for, whose song version is what will play.
    /// `track`: the song as listed, for a hi-res source's search.
    async fn prefetch(&self, video_id: String, song_of: Option<Track>, track: Option<Track>) -> anyhow::Result<()> {
        // For the play it was asked during: a skip in the meantime makes it moot.
        let generation = self.audio.status.wanted_gen.load(Ordering::Relaxed);
        // Looked up now, so the play doesn't wait for it.
        let song = self.song_version(&video_id, song_of.as_ref(), PREFETCH_SONG_WAIT).await;
        let meta = song.clone().or_else(|| song_of.clone()).or_else(|| track);
        let video_id = song.map_or(video_id, |s| s.id);
        // Let the playing song finish downloading first: it gets the whole bandwidth.
        let playing = self.current.lock().unwrap().as_ref().map(|(_, s)| s.clone());
        if let Some(s) = playing {
            s.finished().await;
        }
        if self.audio.status.wanted_gen.load(Ordering::Relaxed) != generation
            || self.prefetched.lock().unwrap().as_ref().is_some_and(|(id, _)| *id == video_id)
        {
            return Ok(());
        }
        log::debug!("prefetch {video_id}");
        let shared = self.open_stream(&video_id, true, meta.as_ref()).await?;
        if let Some((_, old)) = self.prefetched.lock().unwrap().replace((video_id, shared)) {
            old.cancel();
        }
        Ok(())
    }

    async fn lyrics_for(&self, t: &Track, generation: u64, ticket: &lyrics::FetchTicket, genius_enabled: bool) -> LyricsSet {
        let artist = t.artist_line();
        let query = lyrics::Query {
            video_id: &t.id,
            song: &t.title,
            artist: &artist,
            album: t.album.as_ref().map(|a| a.name.as_str()),
            duration: match t.duration {
                Some(d) => Some(d),
                None => self.stream_duration(&t.id).await,
            },
        };
        let fail = std::env::var("YTM_LYRICS_FAIL").ok();
        let set = self.lyrics.fetch(&query, ticket, genius_enabled, |partial| {
            if let Some(partial) = prepare_lyrics_response(partial, fail.as_deref(), false) {
                let _ = self.tx.send(Resp::Lyrics { video_id: t.id.clone(), generation, lyrics: partial, complete: false });
                self.wake();
            }
        }).await.unwrap_or_else(|e| {
            log::warn!("lyrics failed: {e:#}");
            LyricsSet::default()
        });
        prepare_lyrics_response(set, fail.as_deref(), true).expect("final lyrics response")
    }

    /// The song's length from its stream, for a track listed without one (some home,
    /// radio and queue rows). Without a duration Better Lyrics only finds plain lyrics,
    /// so wait for playback to resolve the stream, up to 15 s. The player's own duration
    /// counts too: starting a song clears it, and a restored session sets it.
    async fn stream_duration(&self, video_id: &str) -> Option<u32> {
        for _ in 0..150 {
            let ms = self.current.lock().unwrap().as_ref().filter(|(id, _)| id == video_id).map(|(_, s)| s.duration_ms);
            let ms = ms.filter(|ms| *ms > 0).or_else(|| self.audio.status.duration().map(|d| d.as_millis() as u64));
            if let Some(ms) = ms.filter(|ms| *ms > 0) {
                return Some((ms / 1000) as u32);
            }
            tokio::time::sleep(std::time::Duration::from_millis(100)).await;
        }
        log::info!("lyrics: no duration for {video_id}");
        None
    }

    /// Sign in with the youtube.com cookies the Google sign-in window hands over.
    async fn set_cookie(&self, cookie: &str) -> anyhow::Result<()> {
        let cookie = cookie.trim();
        anyhow::ensure!(!cookie.is_empty(), "no youtube.com cookies found");
        let session = self.api.session_from_cookie(cookie).await.inspect_err(|e| {
            // Names only, never values: enough to see whether SAPISID etc. arrived.
            let names: Vec<&str> = cookie.split(';').filter_map(|kv| kv.trim().split('=').next()).take(40).collect();
            log::warn!("cookie sign-in rejected: {e:#}; cookie names: {names:?}");
        })?;
        self.api.sign_in(session);
        // The sign-in window's copy of the session would go stale as the app takes new
        // cookies, and opening it again would show Google the old ones, which it treats
        // as stolen and signs the session out. Keep only the app's copy.
        let profile = self.login_profile();
        let _ = tokio::task::spawn_blocking(move || crate::login::forget(&profile)).await;
        Ok(())
    }

    async fn start_playback(&self, listed: &str, song_of: Option<&Track>, carried: Option<Track>, track: Option<&Track>, generation: u64, at: std::time::Duration, report: bool) -> anyhow::Result<()> {
        let t0 = std::time::Instant::now();
        // A music video plays as its song when one is found in time (or goes on as the
        // one it was). From here on, everything (prefetch, replay, history) goes by what
        // actually plays.
        let was_carried = carried.is_some();
        let mut song = match carried {
            Some(song) => Some(song),
            None => self.song_version(listed, song_of, PLAY_SONG_WAIT).await,
        };
        // What a hi-res source is asked for: the song that will play, or the video itself.
        let meta = song.clone().or_else(|| song_of.cloned()).or_else(|| track.cloned());
        if self.audio.status.wanted_gen.load(Ordering::Relaxed) != generation {
            return Ok(());
        }
        let mut video_id = song.as_ref().map_or(listed, |s| s.id.as_str()).to_owned();
        let prefetched = self.prefetched.lock().unwrap().take();
        // A reverted song must not replay its buffered hi-res copy: it re-resolves to YouTube.
        let reverted = self.reverted.lock().unwrap().contains(&video_id);
        let replay = self.current.lock().unwrap().take().filter(|(id, s)| !reverted && *id == video_id && s.is_complete()).map(|(_, s)| s);
        let ready = match prefetched {
            Some((id, s)) if id == video_id => Some(s),
            // Replaying the current song keeps the next one's prefetch.
            other if replay.is_some() => {
                *self.prefetched.lock().unwrap() = other;
                replay
            }
            // Playback went elsewhere: that prefetch is moot.
            other => {
                if let Some((_, s)) = other {
                    s.cancel();
                }
                None
            }
        };
        let shared = match ready {
            Some(s) => {
                log::debug!("play {video_id} (gen {generation}): using buffered stream");
                s
            }
            None => {
                if self.audio.status.wanted_gen.load(Ordering::Relaxed) != generation {
                    return Ok(());
                }
                match self.open_stream(&video_id, false, meta.as_ref()).await {
                    Ok(s) => s,
                    // The song won't play: the music video still does.
                    Err(e) if song.is_some() => {
                        log::warn!("{listed}'s song {video_id} won't play ({e:#}); playing the music video");
                        (song, video_id) = (None, listed.to_owned());
                        // The UI took the song as playing already.
                        if was_carried {
                            let _ = self.tx.send(Resp::PlayingAs { generation, listed: listed.to_owned(), song: None });
                        }
                        self.open_stream(listed, false, None).await?
                    }
                    Err(e) => return Err(e),
                }
            }
        };
        // If the song's audio won't start after all, the music video plays instead.
        let fallback = song.is_some().then(|| (self.clone(), listed.to_owned(), report));
        if let Some(song) = song {
            log::info!("play {listed} as its song {video_id}");
            // Carried over, the UI has it already.
            if !was_carried {
                let _ = self.tx.send(Resp::PlayingAs { generation, listed: listed.to_owned(), song: Some(song) });
                (self.wake)();
            }
        }
        let video_id = video_id.as_str();
        *self.current.lock().unwrap() = Some((video_id.to_owned(), shared.clone()));
        log::debug!("play {video_id} (gen {generation}): stream open in {:?}", t0.elapsed());
        if self.audio.status.wanted_gen.load(Ordering::Relaxed) != generation {
            shared.cancel();
            return Ok(());
        }

        let audio = self.audio.clone();
        let tx = self.tx.clone();
        let wake = self.wake.clone();
        // Opening the decoder reads the container header, which blocks on the download.
        // Starting mid-song needs the seekable decoder (it waits for every fragment
        // header); from the top, the non-seekable one starts sooner.
        let seek = !at.is_zero();
        let shared2 = shared.clone();
        let report = (report && self.is_logged_in() && reports_plays()).then(|| (self.clone(), video_id.to_owned()));
        let upgrade = shared2.info.is_none().then(|| (self.clone(), video_id.to_owned(), meta));
        let open = move || -> anyhow::Result<crate::audio::TrackDecoder> {
            let mut d = stream::decoder(shared.clone(), seek)?;
            if seek {
                rodio::Source::try_seek(&mut d, at).map_err(|e| anyhow::anyhow!("seek: {e}"))?;
            }
            Ok(d)
        };
        tokio::task::spawn_blocking(move || match open() {
            Ok(decoder) => {
                log::debug!("play gen {generation}: decoder ready at {at:?} in {:?}", t0.elapsed());
                let _ = tx.send(Resp::StreamStats { generation, stats: stream::Stats::of(&shared2, &decoder) });
                // What a hi-res stream is, as the decoder actually reads it.
                if let Some(mut info) = shared2.info.clone() {
                    info.sample_rate = Some(rodio::Source::sample_rate(&decoder).get());
                    info.channels = Some(rodio::Source::channels(&decoder).get() as u8);
                    let _ = tx.send(Resp::AudioInfo { generation, info });
                }
                wake();
                audio.send(AudioCmd::Start { generation, decoder, shared: shared2, at });
                // Skipped past before it started: that one doesn't count.
                if let Some((this, id)) = report.filter(|_| audio.status.wanted_gen.load(Ordering::Relaxed) == generation) {
                    let rt = this.rt.clone();
                    rt.spawn(async move {
                        match ytm::report_play(&this.api, &id).await {
                            Ok(w) => {
                                log::debug!("reported play of {id}");
                                this.report_watchtime(&id, generation, w).await;
                            }
                            Err(e) => log::warn!("couldn't report play of {id}: {e:#}"),
                        }
                    });
                }
                if let Some((this, id, Some(track))) = upgrade.filter(|_| audio.status.wanted_gen.load(Ordering::Relaxed) == generation) {
                    let rt = this.rt.clone();
                    rt.spawn(async move {
                        this.try_upgrade_hires(id, generation, track).await;
                    });
                }
            }
            Err(e) => match fallback {
                Some((this, listed, report)) => {
                    log::warn!("{listed}'s song won't start ({e}); playing the music video");
                    let _ = tx.send(Resp::PlayingAs { generation, listed: listed.clone(), song: None });
                    this.request(Req::Play { video_id: listed, generation, at, report, song_of: None, song: None, track: None });
                    wake();
                }
                None => {
                    let _ = tx.send(Resp::PlayError { generation, msg: format!("decode: {e}") });
                    wake();
                }
            },
        });
        Ok(())
    }

    /// Report how much of play `generation` is heard, on the web player's schedule
    /// (10, 20 and 30 s in, then every 40 s), with a last report once it ends or is left.
    /// Each covers the stretch played since the one before; time paused doesn't count.
    async fn report_watchtime(&self, id: &str, generation: u64, w: ytm::Watchtime) {
        // Reported as the sign-in and channel that started it, or not at all.
        let epoch = self.api.epoch();
        let status = &self.audio.status;
        let started = std::time::Instant::now();
        let mut flush = w.flush_at.iter().copied();
        let mut due = flush.next().unwrap_or(w.flush_every);
        // The stretch not yet reported, and where the song was at the last check.
        let pos = || status.position().as_secs_f64();
        let (mut from, mut at) = (pos(), pos());
        loop {
            tokio::time::sleep(std::time::Duration::from_secs(1)).await;
            let gone = status.wanted_gen.load(Ordering::Relaxed) != generation;
            if !gone {
                let now = pos();
                // A seek starts a new stretch.
                if now < at || now > at + 5.0 {
                    from = now;
                }
                at = now;
            }
            let elapsed = started.elapsed().as_secs();
            if !gone && elapsed < due {
                continue;
            }
            if self.api.epoch() != epoch {
                log::debug!("stopped reporting listening time of {id}: the account or channel changed");
                return;
            }
            if at > from || gone {
                if let Err(e) = ytm::report_watchtime(&self.api, &w, from, at, started.elapsed().as_secs_f64(), gone).await {
                    log::warn!("couldn't report listening time of {id}: {e:#}");
                }
                from = at;
            }
            if gone {
                log::debug!("reported listening time of {id}");
                return;
            }
            due = flush.next().unwrap_or(due + w.flush_every);
        }
    }

    /// Resolve a stream URL and start downloading it into a new buffer (just its start,
    /// for a prefetch, until playback opens it).
    /// A downloaded song opens from its file.
    /// The song version of the music video `listed`, when `song_of` asks for one: from
    /// this session's lookups, YouTube's own pair (Premium), or a sure signed-out search
    /// match. `None` when there's none, it isn't found within `wait`, or the music video
    /// is downloaded (that file plays, offline too). A failed lookup isn't remembered,
    /// so the next play tries again.
    async fn song_version(&self, listed: &str, song_of: Option<&Track>, wait: std::time::Duration) -> Option<Track> {
        let video = song_of.filter(|t| t.id == listed && t.music_video)?;
        if crate::downloads::path(listed).is_some() {
            return None;
        }
        // Its song version downloaded from Now playing: from the file, no lookup (offline too).
        if let Some(song) = crate::downloads::song_for(listed) {
            return Some(song);
        }
        let start = std::time::Instant::now();
        // Premium gets YouTube's own pair; a search needs the video's length to be sure.
        // The check counts toward the wait (the first one after launch asks YouTube): not
        // back in time, this lookup searches. It finishes anyway, for the next song.
        let premium = match self.api.account() {
            Some(session) => {
                let this = self.clone();
                let check = tokio::spawn(async move { this.is_premium(&session).await });
                tokio::time::timeout(wait, check).await.is_ok_and(|p| p.unwrap_or(false))
            }
            None => false,
        };
        if !premium && (video.duration.is_none() || video.artists.is_empty()) {
            return None;
        }
        let cell = {
            let mut songs = self.songs.lock().unwrap();
            let key = format!("{listed} {premium}");
            match songs.get(&key) {
                Some(cell) => cell.clone(),
                None => {
                    if songs.len() >= 1000 {
                        // Keeps the lookups still running.
                        songs.retain(|_, c| !c.initialized());
                    }
                    songs.entry(key).or_default().clone()
                }
            }
        };
        // Its own task: when the wait runs out the lookup still finishes, so the next play
        // of this video finds the song in the cell.
        let (this, video) = (self.clone(), video.clone());
        let lookup = tokio::spawn(async move {
            cell.get_or_try_init(|| async {
                let found = this.look_up_song(&video, premium).await?;
                match &found {
                    Some(s) => log::info!("song version of {} \"{}\": {} \"{}\"", video.id, video.title, s.id, s.title),
                    None => log::info!("song version of {} \"{}\": none found", video.id, video.title),
                }
                anyhow::Ok(found)
            })
            .await
            .cloned()
        });
        match tokio::time::timeout(wait.saturating_sub(start.elapsed()), lookup).await {
            Ok(Ok(Ok(found))) => found,
            Ok(Ok(Err(e))) => {
                log::debug!("song version of {listed}: {e:#}");
                None
            }
            Ok(Err(e)) => {
                log::debug!("song version of {listed}: lookup stopped: {e}");
                None
            }
            Err(_) => {
                log::debug!("song version of {listed}: not found in {wait:?}, playing the music video");
                None
            }
        }
    }

    async fn look_up_song(&self, video: &Track, premium: bool) -> anyhow::Result<Option<Track>> {
        if premium {
            match ytm::paired_song(&self.api, &video.id).await {
                // YouTube pairs every music video that has a song; trust it when it says none.
                Ok(found) => return Ok(found),
                Err(e) => log::debug!("song pair of {}: {e:#}; searching instead", video.id),
            }
        }
        ytm::searched_song(&self.api, video).await
    }

    async fn open_stream(&self, video_id: &str, prefetch: bool, track: Option<&Track>) -> anyhow::Result<Arc<Shared>> {
        let id = video_id.to_owned();
        if let Some(shared) = tokio::task::spawn_blocking(move || crate::downloads::open(&id)).await? {
            return Ok(shared);
        }
        let (source, s) = self.resolve(video_id, false, track, !self.disable_direct.load(Ordering::Relaxed), prefetch).await?;
        // Atmos arrives already decoded: a complete buffer, no download to run.
        if let Some(data) = s.data {
            return Ok(Shared::from_bytes_with_format(data, s.duration_ms, s.loudness_db, s.format, s.info));
        }
        let shared = Shared::new(s.size, s.duration_ms, s.loudness_db, s.format.clone(), s.info, prefetch);
        self.rt.spawn(stream::download(
            self.http(),
            s.url,
            s.user_agent,
            shared.clone(),
            Some(self.refresher(source, video_id, s.format, track.cloned())),
            s.ranging,
        ));
        Ok(shared)
    }

    /// Resolves a fresh URL from the same source and format, for a download that got a 403.
    fn refresher(&self, source: Source, video_id: &str, format: stream::Format, track: Option<Track>) -> stream::Refresh {
        let (this, id) = (self.clone(), video_id.to_owned());
        Arc::new(move || {
            let (this, id, track) = (this.clone(), id.clone(), track.clone());
            let format = format.clone();
            Box::pin(async move {
                let s = this.resolve_from(source, &id, format.clone(), track.as_ref()).await?;
                // The buffer is laid out for the format it started with.
                anyhow::ensure!(s.format == format, "the stream changed format");
                Ok(s.url)
            })
        })
    }

    /// Download a song into the downloads folder. The listener's sources answer first, so
    /// a saved song is the lossless copy they have; YouTube's best is the fallback. An
    /// Atmos copy is decoded in memory and has no container to write, so it falls back too.
    async fn download(&self, t: &Track, for_video: Option<String>) -> anyhow::Result<PathBuf> {
        let (source, s) = self.resolve(&t.id, true, Some(t), true, false).await?;
        let (source, s) = if matches!(s.format, stream::Format::Pcm { .. }) {
            log::info!("download {}: the source's Atmos copy isn't a file, taking YouTube's", t.id);
            self.resolve(&t.id, true, Some(t), false, false).await?
        } else {
            (source, s)
        };
        log::info!("download {}: {} bytes from {source:?}", t.id, s.size);
        let shared = Shared::new(s.size, s.duration_ms, s.loudness_db, s.format.clone(), s.info, false);
        stream::download(self.http(), s.url, s.user_agent, shared.clone(), Some(self.refresher(source, &t.id, s.format, Some(t.clone()))), s.ranging).await;
        if let Some(e) = shared.error() {
            anyhow::bail!("{e}");
        }
        let audio = shared.bytes().ok_or_else(|| anyhow::anyhow!("the download stopped early"))?;
        let cover = match model::pick(&t.thumbs, 120).map(|u| sized(u, 1200)) {
            Some(url) => async { self.http().get(url).send().await?.error_for_status()?.bytes().await }.await.ok().map(|b| b.to_vec()),
            None => None,
        };
        let (t, duration_ms, loudness) = (t.clone(), shared.duration_ms, shared.loudness_db);
        tokio::task::spawn_blocking(move || crate::downloads::save(&t, &audio, duration_ms, loudness, cover, for_video)).await?
    }

    /// Find a stream URL, trying the fastest source that can play the song. `best`
    /// (downloads) takes the high quality stream whatever the setting, and waits for
    /// the solver it needs. Playback without Premium takes Opus where there is one;
    /// downloads take AAC, which saves as a tagged .m4a. `allow_hires`: try the listener's
    /// addon sources first (playback and downloads). `prefetch`: only somewhere to start is needed,
    /// so a source that would have to be fetched and decoded whole is left for the play.
    async fn resolve(&self, video_id: &str, best: bool, track: Option<&Track>, allow_hires: bool, prefetch: bool) -> anyhow::Result<(Source, ResolvedStream)> {
        // The listener's addons answer for the songs they have; when they miss, YouTube plays.
        let reverted = self.reverted.lock().unwrap().contains(video_id);
        let hires = if allow_hires && !reverted { self.hires.read().unwrap().clone() } else { Vec::new() };
        if let Some(track) = track
            && !hires.is_empty()
        {
            let started = std::time::Instant::now();
            match tokio::time::timeout(HIRES_WAIT, self.from_hires(&hires, track, prefetch)).await {
                Ok(Some(s)) => {
                    if let Some(info) = s.info.as_ref() {
                        log::info!("{video_id}: {} audio from {}", info.badge(), info.source);
                    }
                    return Ok((Source::HiRes, s));
                }
                Ok(None) => log::info!("{video_id}: no hi-res source has a copy ({:.1}s)", started.elapsed().as_secs_f32()),
                Err(_) => log::info!("{video_id}: the hi-res sources gave no answer in {HIRES_WAIT:?}"),
            }
        }
        let hq = best || self.hq.load(Ordering::Relaxed);
        if best
            && !self.jsc.ready()
            && let Some(session) = self.api.account()
            && self.is_premium(&session).await
            && let Err(e) = self.jsc.warm(&self.http()).await
        {
            log::warn!("solver warm-up failed: {e:#}");
        }
        // High quality needs the signed-in player's solver. Until it's prepared (a new
        // install, a new player version: ~5 s or more), play standard quality at once.
        // Without Premium it's never prepared, and standard quality is all there is.
        let solver_ready = self.jsc.ready();
        if hq && !solver_ready && self.api.account().is_some() && !self.known_not_premium() {
            log::info!("{video_id}: solver not ready yet, standard quality for now");
            self.warm_signed_in();
        }
        if hq
            && solver_ready
            && let Some(session) = self.api.account()
            && self.is_premium(&session).await
        {
            match self.resolve_from(Source::WebMusic, video_id, stream::Format::Aac, None).await {
                Ok(s) => return Ok((Source::WebMusic, s)),
                // Not fatal: the usual 128 kbps stream still plays.
                Err(e) => log::warn!("high quality stream failed for {video_id} ({e:#}); using standard quality"),
            }
        }
        let opus = if best { stream::Format::Aac } else { stream::Format::Opus };
        match self.resolve_from(Source::VisionOs, video_id, opus, None).await {
            Ok(s) => Ok((Source::VisionOs, s)),
            Err(first) => {
                // The visionOS player refuses some songs outright (age-gated, or marked as
                // made for kids). The web player — signed in when there's an account, and
                // anonymously otherwise — often still has them, and yt-dlp is the last word
                // for an account that has one.
                log::info!("{video_id} visionOS unavailable ({first:#}); trying the web player");
                match self.resolve_from(Source::WebMusic, video_id, stream::Format::Aac, None).await {
                    Ok(s) => Ok((Source::WebMusic, s)),
                    Err(web) => {
                        log::warn!("{video_id}: the web player refused too ({web:#})");
                        if self.api.account().is_some()
                            && let Ok(s) = self.resolve_from(Source::YtDlp, video_id, stream::Format::Aac, None).await
                        {
                            return Ok((Source::YtDlp, s));
                        }
                        Err(first)
                    }
                }
            }
        }
    }

    /// `format`: the container the caller needs (the visionOS player picks Opus or AAC
    /// from it). The hi-res source re-resolves by searching for `track` again.
    async fn resolve_from(&self, source: Source, video_id: &str, format: stream::Format, track: Option<&Track>) -> anyhow::Result<ResolvedStream> {
        let plain = |s: innertube::Stream, ua: &str| ResolvedStream {
            url: s.url,
            size: s.size,
            duration_ms: s.duration_ms,
            user_agent: ua.to_owned(),
            loudness_db: s.loudness_db,
            format: stream::Format::from_opus(s.opus),
            info: None,
            ranging: stream::Ranging::Query,
            data: None,
        };
        Ok(match source {
            Source::VisionOs => plain(self.visionos_stream(video_id, format == stream::Format::Opus).await?, innertube::UA),
            Source::WebMusic => {
                if let Some(session) = self.api.account() {
                    match session.audio_stream(&self.http(), &self.jsc, video_id).await {
                        Ok(s) => plain(s, webmusic::UA),
                        // A signed-in answer with no stream still has an anonymous one.
                        Err(e) => {
                            log::info!("{video_id}: the signed-in web player refused ({e:#}); asking anonymously");
                            plain(webmusic::audio_stream_anon(&self.http(), &self.jsc, video_id).await?, webmusic::UA)
                        }
                    }
                } else {
                    plain(webmusic::audio_stream_anon(&self.http(), &self.jsc, video_id).await?, webmusic::UA)
                }
            }
            Source::YtDlp => {
                let session = self.api.account().ok_or_else(|| anyhow::anyhow!("sign in to play this song"))?;
                let s = ytdlp::resolve(&self.http(), &self.data_dir, &session.cookie, video_id).await?;
                // Cookies Google replaced while yt-dlp used the session.
                self.api.keep(&session, s.replaced.iter().map(String::as_str));
                // yt-dlp's JSON doesn't carry YouTube's loudness figure.
                ResolvedStream { url: s.url, size: s.size, duration_ms: s.duration_ms, user_agent: s.user_agent, loudness_db: None, format: stream::Format::Aac, info: None, ranging: stream::Ranging::Query, data: None }
            }
            Source::HiRes => {
                let track = track.ok_or_else(|| anyhow::anyhow!("no song to look up"))?;
                let sources = self.hires.read().unwrap().clone();
                anyhow::ensure!(!sources.is_empty(), "no hi-res source is set");
                self.from_hires(&sources, track, false).await.ok_or_else(|| anyhow::anyhow!("no hi-res source has a copy"))?
            }
        })
    }

    /// The listener's addons, searched together. Atmos leads when the preference is on,
    /// then hi-res/lossless; `None` when none of them has a copy (a miss, not a fault).
    async fn from_hires(&self, sources: &[Arc<hires::Client>], track: &Track, prefetch: bool) -> Option<ResolvedStream> {
        let atmos = self.atmos.load(Ordering::Relaxed);
        let http = self.http();
        let Some(found) = hires::find_all(&http, sources, track, atmos, prefetch).await else {
            log::info!("hi-res: no copy of \"{}\" on {} source(s)", track.title, sources.len());
            return None;
        };
        Some(ResolvedStream {
            url: found.url,
            size: found.size,
            duration_ms: found.duration_ms,
            user_agent: hires::agent().to_owned(),
            loudness_db: None,
            format: found.format,
            info: Some(found.info),
            ranging: stream::Ranging::Header,
            data: found.data,
        })
    }

    /// Get the signed-in playback path ready in the background, so the first Premium-only
    /// or age-restricted song doesn't wait for the Premium check or the solver setup that
    /// each new YouTube player version needs (~5 s, every few days).
    pub fn warm_signed_in(&self) {
        let this = self.clone();
        self.rt.spawn(async move {
            let Some(session) = this.api.account() else { return };
            if this.is_premium(&session).await
                && let Err(e) = this.jsc.warm(&this.http()).await
            {
                log::warn!("solver warm-up failed: {e:#}");
            }
        });
    }

    /// The Premium check has answered, and the account doesn't have it. Doesn't ask or
    /// wait: while a check is running, it's not known yet.
    fn known_not_premium(&self) -> bool {
        self.premium.try_lock().is_ok_and(|p| matches!(*p, Ok(false)))
    }

    /// Premium accounts can stream signed-in web player URLs without a PO token.
    async fn is_premium(&self, session: &webmusic::Session) -> bool {
        const PREMIUM_RETRY: std::time::Duration = std::time::Duration::from_secs(300);
        let mut premium = self.premium.lock().await;
        match *premium {
            Ok(p) => return p,
            Err(Some(at)) if at.elapsed() < PREMIUM_RETRY => return false,
            Err(_) => {}
        }
        match session.is_premium(&self.http()).await {
            Ok(p) => {
                log::info!("account has Premium: {p}");
                *premium = Ok(p);
                p
            }
            Err(e) => {
                log::warn!("Premium check failed: {e:#}");
                *premium = Err(Some(std::time::Instant::now()));
                false
            }
        }
    }

    async fn visionos_stream(&self, video_id: &str, opus: bool) -> anyhow::Result<innertube::Stream> {
        let vd = self.api.visitor_data(false).await?;
        match innertube::audio_stream(&self.http(), video_id, &vd, opus).await {
            Ok(s) => Ok(s),
            Err(e) if needs_account(&e) => Err(e),
            Err(e) => {
                // A stale/flagged visitor ID is the usual cause; retry once with a fresh one.
                log::info!("visionOS player: {e:#}; retrying with new visitor data");
                let vd = self.api.visitor_data(true).await?;
                innertube::audio_stream(&self.http(), video_id, &vd, opus).await
            }
        }
    }

    /// Webview profile used by the sign-in window.
    pub fn login_profile(&self) -> PathBuf {
        self.data_dir.join("webview")
    }

    /// youtube.com's "Most replayed" curve for one video: read from the disk while the
    /// answer there is still in date, and asked once when it isn't. What a failed request
    /// leaves behind is the last curve kept, however old — a stale one is a better guess
    /// than none, and a failure is not an answer about the video, so it's kept nowhere.
    async fn replay_curve(&self, video_id: &str) -> Option<crate::bestpart::Heatmap> {
        if !crate::bestpart::is_video_id(video_id) {
            return None;
        }
        let mut curves = crate::bestpart::Curves::open(&self.data_dir);
        if let Some(heat) = curves.fresh(video_id, crate::bestpart::now_ms()) {
            return heat;
        }
        let answer = match tokio::time::timeout(HEATMAP_WAIT, crate::innertube::web_next(&self.http(), video_id)).await {
            Ok(Ok(answer)) => answer,
            _ => return curves.stale(video_id),
        };
        let heat = crate::bestpart::parse_heatmap(&answer);
        curves.put(video_id, heat.as_ref(), crate::bestpart::now_ms());
        heat
    }

    /// Report an error from outside the request flow (e.g. the sign-in window).
    pub fn report_error(&self, msg: String) {
        let _ = self.tx.send(Resp::Error(msg));
        self.wake();
    }

    pub fn data_dir(&self) -> &std::path::Path {
        &self.data_dir
    }

    pub fn set_high_quality(&self, on: bool) {
        self.hq.store(on, Ordering::Relaxed);
    }

    /// Prefer a Dolby Atmos rendition from the hi-res sources when they offer one.
    pub fn set_prefer_atmos(&self, on: bool) {
        self.atmos.store(on, Ordering::Relaxed);
    }

    /// Play YouTube immediately and upgrade to hi-res in the background.
    pub fn set_disable_direct_stream(&self, on: bool) {
        self.disable_direct.store(on, Ordering::Relaxed);
    }

    /// Send a song back to YouTube audio: later plays of it skip the hi-res sources.
    pub fn revert_quality(&self, video_id: &str) {
        self.reverted.lock().unwrap().insert(video_id.to_owned());
    }

    /// Allow hi-res sources again for a song that was sent back to YouTube audio.
    pub fn upgrade_quality(&self, video_id: &str) {
        self.reverted.lock().unwrap().remove(video_id);
    }

    /// After playback starts on YouTube, opportunistically look for a hi-res
    /// rendition from addons and upgrade the playing stream in place.
    async fn try_upgrade_hires(&self, video_id: String, generation: u64, track: Track) {
        if self.audio.status.wanted_gen.load(Ordering::Relaxed) != generation {
            return;
        }
        if self.reverted.lock().unwrap().contains(&video_id) {
            return;
        }
        let hires = self.hires.read().unwrap().clone();
        if hires.is_empty() {
            return;
        }

        let _ = self.tx.send(Resp::UpgradingQuality { generation, active: true });
        self.wake();
        struct UpgradeGuard<'a> {
            backend: &'a Backend,
            generation: u64,
        }
        impl<'a> Drop for UpgradeGuard<'a> {
            fn drop(&mut self) {
                let _ = self.backend.tx.send(Resp::UpgradingQuality { generation: self.generation, active: false });
                self.backend.wake();
            }
        }
        let _guard = UpgradeGuard { backend: self, generation };

        let started = std::time::Instant::now();
        let stream_res = match tokio::time::timeout(HIRES_WAIT, self.from_hires(&hires, &track, false)).await {
            Ok(Some(s)) => s,
            Ok(None) => {
                log::info!("{video_id}: no hi-res source has a copy ({:.1}s)", started.elapsed().as_secs_f32());
                return;
            }
            Err(_) => {
                log::info!("{video_id}: the hi-res sources gave no answer in {HIRES_WAIT:?}");
                return;
            }
        };

        if self.audio.status.wanted_gen.load(Ordering::Relaxed) != generation {
            log::debug!("hi-res upgrade for {video_id} dropped: generation changed");
            return;
        }
        if self.reverted.lock().unwrap().contains(&video_id) {
            log::debug!("hi-res upgrade for {video_id} dropped: reverted to YouTube");
            return;
        }

        if let Some(info) = stream_res.info.as_ref() {
            log::info!("{video_id}: upgrading to {} audio from {}", info.badge(), info.source);
        }

        let (source, s) = (Source::HiRes, stream_res);
        let shared = if let Some(data) = s.data {
            Shared::from_bytes_with_format(data, s.duration_ms, s.loudness_db, s.format.clone(), s.info.clone())
        } else {
            let shared = Shared::new(s.size, s.duration_ms, s.loudness_db, s.format.clone(), s.info.clone(), false);
            self.rt.spawn(stream::download(
                self.http(),
                s.url,
                s.user_agent,
                shared.clone(),
                Some(self.refresher(source, &video_id, s.format.clone(), Some(track.clone()))),
                s.ranging,
            ));
            shared
        };

        let pos = self.audio.status.position();
        let sampled = std::time::Instant::now();
        let is_playing = self.audio.status.playing.load(Ordering::Relaxed);
        let shared_decode = shared.clone();
        let res = tokio::task::spawn_blocking(move || {
            let seekable = !pos.is_zero();
            let mut d = stream::decoder(shared_decode.clone(), seekable)?;
            let actual_pos = if is_playing { pos + sampled.elapsed() } else { pos };
            if seekable {
                rodio::Source::try_seek(&mut d, actual_pos).map_err(|e| anyhow::anyhow!("seek: {e}"))?;
            }
            Ok::<_, anyhow::Error>((d, actual_pos, seekable))
        })
        .await;

        let (decoder, actual_pos, seekable) = match res {
            Ok(Ok(tuple)) => tuple,
            Ok(Err(e)) => {
                log::warn!("failed to decode hi-res stream for {video_id} ({e:#}); continuing with standard quality");
                return;
            }
            Err(e) => {
                log::warn!("hi-res decoder task failed for {video_id} ({e:#}); continuing with standard quality");
                return;
            }
        };

        if self.audio.status.wanted_gen.load(Ordering::Relaxed) != generation {
            shared.cancel();
            return;
        }
        if self.reverted.lock().unwrap().contains(&video_id) {
            shared.cancel();
            return;
        }

        *self.current.lock().unwrap() = Some((video_id, shared.clone()));
        if let Some(mut info) = shared.info.clone() {
            info.sample_rate = Some(rodio::Source::sample_rate(&decoder).get());
            info.channels = Some(rodio::Source::channels(&decoder).get() as u8);
            let _ = self.tx.send(Resp::AudioInfo { generation, info });
            self.wake();
        }
        let _ = self.tx.send(Resp::StreamStats { generation, stats: stream::Stats::of(&shared, &decoder) });
        self.audio.send(AudioCmd::Upgrade {
            generation,
            decoder,
            shared,
            at: actual_pos,
            seekable,
        });
    }

    /// Upgrade the active song if it is playing standard YouTube quality and not reverted.
    pub fn try_upgrade_active(&self, generation: u64, track: Option<Track>) {
        let (video_id, has_hires) = {
            let current = self.current.lock().unwrap();
            let Some((id, shared)) = current.as_ref() else { return };
            (id.clone(), shared.info.is_some())
        };
        if has_hires {
            return;
        }
        let Some(track) = track else { return };
        let this = self.clone();
        self.rt.spawn(async move {
            this.try_upgrade_hires(video_id, generation, track).await;
        });
    }

    /// Point the hi-res sources at the links in `links`, one per line (empty: none). The
    /// links themselves aren't logged: they can carry a token.
    pub fn set_hires_source(&self, links: &str) {
        let mut clients: Vec<Arc<hires::Client>> = Vec::new();
        let mut seen = std::collections::HashSet::new();
        let mut rejected = 0;
        for line in links.lines() {
            let line = line.trim();
            // One client per distinct link. An exact repeat is skipped (it would fire
            // duplicate searches and streams at one server, which is how a working
            // source starts answering 502); a different link on the same host is a
            // separate source the user asked for and is kept.
            if line.is_empty() || !seen.insert(line.to_owned()) {
                continue;
            }
            match hires::Client::new(line) {
                Some(client) => clients.push(Arc::new(client)),
                None => rejected += 1,
            }
        }
        let host_list: Vec<String> = clients.iter().map(|c| c.host()).collect();
        match clients.len() {
            0 if rejected == 0 => log::info!("hi-res sources: none"),
            0 => log::warn!("hi-res sources: none usable ({rejected} not an http(s) link)"),
            1 => log::info!("hi-res source set: {}", host_list[0]),
            n => log::info!("{n} hi-res sources set: {}", host_list.join(", ")),
        }
        if rejected > 0 && !clients.is_empty() {
            log::warn!("hi-res sources: {rejected} entry(s) aren't http(s) links and were skipped");
        }
        *self.hires.write().unwrap() = clients;
    }

    /// Like or unlike a selection, one at a time, then check Liked Music and try again
    /// what didn't take. Unlikes still listed after that count as refused; likes aren't
    /// counted so (songs that can't be played are liked but not listed).
    async fn like_many(&self, ids: Vec<String>, like: bool) -> anyhow::Result<Resp> {
        let total = ids.len();
        let (done, failed) = like_many(&self.api, ids, like, |taken, n| {
            let _ = self.tx.send(Resp::LikeProgress { taken: taken.into_iter().map(str::to_owned).collect(), done: n, total, like });
            self.wake();
        })
        .await;
        // Even when all were refused: the app stops waiting on them and shows them as they are.
        Ok(Resp::LikedMany { video_ids: done, failed, like })
    }

    /// Send a playlist's first page right away, then each next page as it arrives
    /// (YouTube takes about half a second per page of 100). The last one is returned.
    async fn stream_playlist(&self, id: String, load: u64, me: bool) -> anyhow::Result<Resp> {
        let (c, mut token, limit) = ytm::playlist_start(&self.api, &id, me, None).await?;
        let mut have = c.tracks.len();
        let mut resp = Resp::Collection { load, c, more: token.is_some() && have < limit };
        while let Some(t) = token.take().filter(|_| have < limit) {
            let _ = self.tx.send(resp);
            self.wake();
            // Failing here, the page keeps what came.
            let (mut tracks, mut set_ids, next) = ytm::playlist_more(&self.api, &t, me).await?;
            tracks.truncate(limit - have);
            set_ids.truncate(limit - have);
            have += tracks.len();
            token = next.filter(|_| !tracks.is_empty());
            resp = Resp::CollectionMore { id: id.clone(), load, more: token.is_some() && have < limit, tracks, set_ids };
        }
        Ok(resp)
    }

    pub fn is_logged_in(&self) -> bool {
        self.api.account().is_some()
    }
}

/// Test instances (`YTM_BACKGROUND`) keep plays out of the account's history unless
/// `YTM_REPORT_PLAYS` is set.
fn reports_plays() -> bool {
    std::env::var_os("YTM_BACKGROUND").is_none() || std::env::var_os("YTM_REPORT_PLAYS").is_some()
}

#[derive(Clone, Copy, Debug)]
enum Source {
    VisionOs,
    WebMusic,
    YtDlp,
    /// The listener's own addon server (see `hires`).
    HiRes,
}

struct ResolvedStream {
    url: String,
    size: u64,
    duration_ms: u64,
    user_agent: String,
    loudness_db: Option<f32>,
    format: stream::Format,
    /// What the player can say about a hi-res stream (codec, rate, depth, size).
    info: Option<hires::Info>,
    /// How this source takes byte ranges.
    ranging: stream::Ranging,
    /// Already-decoded audio (Dolby Atmos out of DASH): no download to run.
    data: Option<Vec<u8>>,
}

/// The anonymous visionOS player refused because the song needs an account:
/// age-restricted (LOGIN_REQUIRED) or Music Premium only.
fn needs_account(e: &anyhow::Error) -> bool {
    let msg = e.to_string();
    msg.contains("LOGIN_REQUIRED") || msg.contains("Premium")
}

/// Keep the signed-in release feed's order, using US charts and the user's home artists.
/// When nothing in this week's releases is by one of them — a small account, or a charts
/// page that named no artists — the feed is already cut for this listener, so its own
/// newest releases stand. An empty lead shelf is the worse answer.
fn popular_new_albums(albums: &[Card], ranked_artists: &[String], preferred_artists: &[String]) -> Vec<Card> {
    let chart_ids: std::collections::HashSet<&str> = ranked_artists.iter().chain(preferred_artists).map(String::as_str).collect();
    let by_artist = |album: &Card| album.links.iter().any(|a| a.id.as_deref().is_some_and(|id| chart_ids.contains(id)));
    let ranked = albums.iter().any(by_artist);
    let mut seen = std::collections::HashSet::new();
    albums
        .iter()
        .filter(|album| !ranked || by_artist(album))
        .filter(|album| seen.insert(match &album.target {
            Target::Album(id) => id.as_str(),
            _ => album.title.as_str(),
        }))
        .take(16)
        .cloned()
        .collect()
}

/// "Episodes for later" is listed even when empty; hide it then.
fn saved_playlist_visible(card: &Card) -> bool {
    card.target != Target::Playlist("SE".into()) || card.subtitle.split_whitespace().any(|w| w.parse::<u64>().is_ok_and(|n| n > 0))
}

pub fn compact(n: u64) -> String {
    let (v, unit) = match n {
        0..1_000 => return n.to_string(),
        1_000..1_000_000 => (n as f64 / 1e3, "K"),
        1_000_000..1_000_000_000 => (n as f64 / 1e6, "M"),
        _ => (n as f64 / 1e9, "B"),
    };
    // "6M", not "6.0M"; three significant figures and up need no decimal.
    let s = if v >= 100.0 { format!("{v:.0}") } else { format!("{v:.1}") };
    format!("{}{unit}", s.strip_suffix(".0").unwrap_or(&s))
}

// Larger art URL for the background / now-playing view.
pub fn art_url(t: &Track) -> Option<String> {
    model::pick(&t.thumbs, 120).map(|u| sized(u, 544))
}

#[cfg(test)]
mod explore_tests {
    use super::*;

    fn card(title: &str, target: Target, artist_id: Option<&str>, subtitle: &str) -> Card {
        Card {
            title: title.into(),
            subtitle: subtitle.into(),
            thumbs: vec![],
            target,
            round: false,
            links: artist_id.map(|id| model::Link { name: "Artist".into(), id: Some(id.into()) }).into_iter().collect(),
        }
    }

    #[test]
    fn failed_sources_are_filtered_from_both_lyrics_stages() {
        let source = |provider| lyrics::Lyrics {
            lines: vec![lyrics::Line { text: "line".into(), ..Default::default() }],
            sync: lyrics::Sync::None,
            provider,
            language: None,
            songwriters: vec![],
        };
        let partial = LyricsSet { sources: vec![source(lyrics::Provider::LrclibPlain), source(lyrics::Provider::UnisonPlain)] };
        let final_set = LyricsSet { sources: vec![source(lyrics::Provider::LrclibPlain), source(lyrics::Provider::GeniusPlain)] };
        assert!(prepare_lyrics_response(partial.clone(), Some(" lrclib-plain, unison-plain "), false).is_none());
        let interim = prepare_lyrics_response(partial, Some("lrclib-plain"), false).unwrap();
        assert_eq!(interim.sources[0].provider, lyrics::Provider::UnisonPlain);
        let filtered = prepare_lyrics_response(final_set.clone(), Some("lrclib-plain"), true).unwrap();
        assert_eq!(filtered.sources[0].provider, lyrics::Provider::GeniusPlain);
        assert!(prepare_lyrics_response(final_set, Some("lrclib-plain,genius-plain"), true).unwrap().sources.is_empty());
    }

    #[test]
    fn genius_about_always_completes_with_the_requested_id() {
        let missing = finish_genius_about(Some("video".into()), None);
        assert!(matches!(missing, Some(Resp::GeniusAbout { video_id, description: None }) if video_id == "video"));
        let answer = Some(Resp::GeniusAbout { video_id: "video".into(), description: Some("A description".into()) });
        assert!(matches!(finish_genius_about(Some("video".into()), answer), Some(Resp::GeniusAbout { video_id, description: Some(text) }) if video_id == "video" && text == "A description"));
        assert!(finish_genius_about(None, None).is_none());
    }

    #[test]
    fn new_releases_only_include_charting_artists_and_deduplicate() {
        let album = |id: &str, artist_id: &str| card(id, Target::Album(id.into()), Some(artist_id), "Album");
        let albums = vec![album("obscure", "other"), album("favorite-release", "favorite"), album("first-release", "popular"), album("second-release", "popular"), album("first-release", "popular")];
        let found = popular_new_albums(&albums, &["popular".into(), "popular".into()], &["favorite".into()]);
        assert_eq!(found.iter().map(|c| c.title.as_str()).collect::<Vec<_>>(), ["favorite-release", "first-release", "second-release"]);
    }

    #[test]
    fn new_releases_fall_back_to_the_feed_when_no_artist_charts() {
        let album = |id: &str| card(id, Target::Album(id.into()), Some("unranked"), "Album");
        let albums = vec![album("first"), album("second"), album("second")];
        // A charts page that named no artists, or a small account: the ranked cut would be
        // empty, so the feed's own newest releases stand rather than an empty shelf.
        let found = popular_new_albums(&albums, &[], &[]);
        assert_eq!(found.iter().map(|c| c.title.as_str()).collect::<Vec<_>>(), ["first", "second"]);
    }

    #[test]
    fn empty_episodes_for_later_is_hidden() {
        let item = |id: &str, subtitle: &str| card("Episodes for later", Target::Playlist(id.into()), None, subtitle);
        assert!(!saved_playlist_visible(&item("SE", "Auto playlist")));
        assert!(!saved_playlist_visible(&item("SE", "Auto playlist • 0 episodes")));
        assert!(saved_playlist_visible(&item("SE", "Auto playlist • 2 episodes")));
        assert!(saved_playlist_visible(&item("PLcustom", "Playlist")));
    }

    #[test]
    fn woven_results_keep_ranks_and_drop_repeats() {
        let t = |id: &str| model::Track { id: id.into(), title: id.into(), artists: vec![], album: None, duration: None, thumbs: vec![], track_nr: None, plays: None, music_video: false, episode: false };
        let out = weave(vec![vec![t("s1"), t("s2"), t("s3")], vec![t("v1"), t("s2"), t("v3")]]);
        assert_eq!(out.iter().map(|x| x.id.as_str()).collect::<Vec<_>>(), ["s1", "v1", "s2", "s3", "v3"]);
    }
}

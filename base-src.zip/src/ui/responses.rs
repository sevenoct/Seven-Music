//! What the backend answers, applied to the app.

use std::collections::HashSet;
use std::sync::atomic::Ordering;
use std::time::Duration;

use souvlaki::MediaControlEvent;

use crate::audio::{AudioCmd, AudioEvent};
use crate::backend::{Req, Resp};
use crate::model::{ShelfKind, Track};
use crate::ytm::HomePage;

use super::{Action, App, Dialog, HomeState, LibTab, MixFrom, Page, PlayingAs, Repeat, dev_var};

impl App {
    pub(super) fn pump(&mut self, now: f64) {
        let cover = self.media_cover.lock().unwrap().take();
        // The listed track's art, with what plays's title, artists and length.
        if let Some((id, file)) = cover
            && self.current().is_some_and(|t| t.id == id)
            && self.mix_hold().is_none()
            && let Some(track) = self.playing_track().cloned()
            && let Some(m) = &mut self.media
        {
            m.set_track(&track.title, &track.artist_line(), track.album.as_ref().map(|a| a.name.as_str()), Some(&file), track.duration);
        }
        while let Ok(r) = self.ch.resp_rx.try_recv() {
            self.on_resp(r, now);
        }
        while let Ok(ev) = self.ch.audio_rx.try_recv() {
            match ev {
                AudioEvent::Finished { generation } if generation == self.generation && self.jam.follows() => {}
                AudioEvent::Finished { generation } if generation == self.generation => {
                    if self.queue.repeat == Repeat::One {
                        self.play_current();
                    } else {
                        // The sleeve was this song's: put it down rather than keep its
                        // decoder, frame and texture for the rest of the session.
                        self.deload_motion();
                        self.next();
                    }
                }
                AudioEvent::Finished { .. } => {}
                // Crossfade into the next song; repeat-one and the end of the queue wait for the end.
                AudioEvent::Ending { generation } if generation == self.generation && !self.jam.follows() && self.queue.repeat != Repeat::One => {
                    // Automix: the next song eases in under this one, which keeps the
                    // player until the blend has given the next song the louder half
                    // (see `MixFrom`).
                    if let Some(from) = self.playing_track().cloned() {
                        let total = self
                            .audio
                            .status
                            .duration()
                            .map(|d| d.as_secs_f32())
                            .or_else(|| from.duration.map(|d| d as f32))
                            .unwrap_or(0.0);
                        let mix = self.audio.status.mix_secs(Some(std::time::Duration::from_secs_f32(total)));
                        if total > 0.0 && mix > 0.5 {
                            self.pending_mix = Some(MixFrom { track: from, total, mix, started: false, released: false });
                        }
                    }
                    let before = self.playing_id().map(str::to_owned);
                    self.handoff = true;
                    self.next();
                    self.handoff = false;
                    if self.playing_id().map(str::to_owned) != before {
                        self.mix_from = self.pending_mix.take();
                    } else {
                        self.pending_mix = None;
                    }
                }
                AudioEvent::Ending { .. } => {}
                AudioEvent::Interrupted { generation, at, reason } if generation == self.generation => self.recover(at, &reason),
                AudioEvent::Interrupted { .. } => {}
                AudioEvent::Error(e) => self.toast(e),
            }
        }
        // Once the next song is the louder of the two, it takes the player over; the
        // caption stays while the handoff's tail runs out.
        let released = self.mix_from.as_ref().is_some_and(|h| h.released);
        let switched = self.watch_mix();
        let over = self.mix_over();
        if (switched || over) && !released {
            self.release_mix();
        }
        if over {
            self.mix_from = None;
        }
        while let Ok(ev) = self.ch.media_rx.try_recv() {
            log::debug!("media: {ev:?}");
            // Take the button for what it asks for, not as a flip of wherever we happen to
            // be: a room already holding still doesn't start because Windows said "pause",
            // and every answer here goes through `toggle`, so the party hears about it.
            match ev {
                MediaControlEvent::Play if !self.playing() => self.toggle(),
                MediaControlEvent::Pause | MediaControlEvent::Stop if self.playing() => self.toggle(),
                MediaControlEvent::Toggle => self.toggle(),
                MediaControlEvent::Next => self.next(),
                MediaControlEvent::Previous => self.prev(),
                _ => {}
            }
        }
        // `playing` can still be the last song's for a frame after a stop: only this
        // generation having started ends the wait.
        if self.buffering && self.playing() && self.audio.status.playing_gen.load(Ordering::Relaxed) == self.generation {
            self.buffering = false;
            self.skip_streak = 0;
            self.prefetch_next();
            // Dev hook: YTM_SEEK=<secs> jumps into the first track once it starts.
            if self.generation == 1 {
                if let Some(s) = std::env::var("YTM_SEEK").ok().and_then(|v| v.parse::<f32>().ok()) {
                    self.audio.send(AudioCmd::Seek(Duration::from_secs_f32(s)));
                }
                // YTM_SEEK_LATER=<secs>@<delay> seeks again that many seconds later.
                if let Some((s, d)) = dev_var("YTM_SEEK_LATER").and_then(|v| v.split_once('@')).and_then(|(s, d)| Some((s.parse::<f32>().ok()?, d.parse::<f32>().ok()?))) {
                    let audio = self.audio.clone();
                    std::thread::spawn(move || {
                        std::thread::sleep(Duration::from_secs_f32(d));
                        audio.send(AudioCmd::Seek(Duration::from_secs_f32(s)));
                    });
                }
            }
        }
        if self.suggest_due.is_some_and(|d| now >= d) {
            self.suggest_due = None;
            let q = self.search_text.trim().to_owned();
            // An empty box signed in shows the account's recent searches.
            if self.forgets_pending == 0 && (!q.is_empty() || self.logged_in) {
                self.backend.request(Req::Suggest { query: q, round: self.suggest_round });
            }
        }
    }

    /// A search's results are on screen: the first result clicked becomes what
    /// "Recently Searched" remembers, not the words that were typed.
    pub(super) fn expect_search_click(&mut self, query: &str) {
        if matches!(&self.page, Page::Search(q) if q == query) {
            self.search_pending = true;
        }
    }

    /// The entry a click makes: the item itself, with the artwork it was shown with.
    fn search_click_entry(&self, a: &Action) -> Option<super::RecentSearch> {
        let r = self.search.as_ref()?;
        let best = |thumbs: &[crate::model::Thumb]| thumbs.iter().max_by_key(|t| t.width).map(|t| t.url.clone());
        let song = |t: &Track| {
            Some(super::RecentSearch {
                query: r.query.clone(),
                target: Some(crate::model::Target::Song(t.clone())),
                title: t.title.clone(),
                subtitle: format!("Song • {}", t.artist_line()),
                thumb: best(&t.thumbs),
                round: false,
            })
        };
        let card = |target: &crate::model::Target| {
            let c = r.artists.iter().chain(&r.albums).chain(&r.playlists).find(|c| c.target == *target)?;
            Some(super::RecentSearch {
                query: r.query.clone(),
                target: Some(target.clone()),
                title: c.title.clone(),
                subtitle: c.subtitle.clone(),
                thumb: best(&c.thumbs),
                round: c.round,
            })
        };
        match a {
            Action::Open(crate::model::Target::Song(t)) | Action::Radio(t) => song(t),
            Action::Open(target) | Action::PlayCollection(target, _) => card(target),
            Action::Play(tracks, i) => tracks.get(*i).and_then(song),
            _ => None,
        }
    }

    /// Record the thing the search's first click opened, once.
    pub(super) fn remember_search_click(&mut self, a: &Action) {
        if !self.search_pending || !matches!(self.page, Page::Search(_)) {
            return;
        }
        let Some(entry) = self.search_click_entry(a) else { return };
        self.search_pending = false;
        // One entry per thing; a bare query left by an older version goes with it.
        self.recent_searches.retain(|s| {
            s.target.as_ref() != entry.target.as_ref() && !(s.target.is_none() && s.query.eq_ignore_ascii_case(&entry.query))
        });
        self.recent_searches.insert(0, entry);
        self.recent_searches.truncate(8);
    }

    fn on_resp(&mut self, r: Resp, now: f64) {
        match r {
            Resp::Home(page) => self.on_home(page),
            Resp::HomeMore { token, page } => {
                if let Some(h) = &mut self.home
                    && h.loading_more.as_ref().is_some_and(|(_, pending)| pending == &token)
                {
                    h.shelves.extend(page.shelves);
                    h.continuation = page.continuation;
                    h.loading_more = None;
                }
            }
            Resp::Explore(e) => {
                self.explore = Some(e);
                self.loading = false;
            }
            Resp::Search(r) => {
                if self.smoke.as_ref() == Some(&r.query) {
                    self.smoke = None;
                    if !r.tracks.is_empty() {
                        log::info!("smoke: playing {}", r.tracks[0].title);
                        self.play_list(r.tracks.clone(), 0);
                    }
                }
                self.expect_search_click(&r.query);
                self.search = Some(r);
                self.loading = false;
            }
            Resp::SearchForgotten => {
                // Replies dropped meanwhile left the list behind what's typed: ask again.
                self.forgets_pending = self.forgets_pending.saturating_sub(1);
                if self.forgets_pending == 0 {
                    self.suggest_due = Some(now);
                }
            }
            Resp::Suggest { query, round, terms } => {
                if round == self.suggest_round && self.forgets_pending == 0 {
                    // Keep late answers for backspacing/revisiting, but never display
                    // an answer for a query other than the one currently in the box.
                    self.suggest_cache.retain(|(q, _)| q != &query);
                    self.suggest_cache.push_back((query.clone(), terms.clone()));
                    if self.suggest_cache.len() > 32 {
                        self.suggest_cache.pop_front();
                    }
                    if self.search_text.trim() == query {
                        self.suggestions = (query, terms);
                        self.suggest_sel = None;
                    }
                }
            }
            Resp::Collection { load, c, more } => self.collection_in(load, c, more),
            Resp::CollectionMore { id, load, tracks, set_ids, more } => self.collection_more(id, load, tracks, set_ids, more),
            Resp::Artist(a) => {
                // A slow answer for an artist left meanwhile doesn't replace the one on screen.
                if matches!(&self.page, Page::Artist(id) if *id != a.id) {
                    return;
                }
                if self.page == Page::Artist(a.id.clone()) {
                    self.loading = false;
                }
                let apple_key = format!("artist:{}", a.id);
                let answered = self.apple_artists.get(&a.id).is_some_and(Option::is_some);
                let cooling = self.apple.missed.get(&apple_key).is_some_and(|t| t.elapsed() < std::time::Duration::from_secs(120));
                if !answered && !cooling {
                    let id = a.id.clone();
                    let name = a.name.clone();
                    if self.apple.waiting.insert(apple_key) {
                        self.backend.request(Req::AppleArtist { id, name });
                    }
                }
                self.artist = Some(a);
            }
            Resp::Library(mut l) => {
                // A half that didn't load keeps what was shown (or last launch's sidebar),
                // rather than emptying it.
                if l.playlists_failed {
                    l.playlists = self.library.as_ref().map(|o| o.playlists.clone()).or_else(|| self.sidebar_cache.clone()).unwrap_or_default();
                }
                if l.albums_failed {
                    l.albums = self.library.as_ref().map(|o| o.albums.clone()).unwrap_or_default();
                }
                self.library = Some(l);
                self.loading = false;
            }
            Resp::History(h) => {
                self.history = Some(h);
                self.loading = false;
            }
            Resp::Uploads(t) => {
                self.uploads = Some(t);
                if self.page == Page::Library(LibTab::Uploads) {
                    self.loading = false;
                }
            }
            Resp::Downloaded { title, path } => {
                log::info!("downloaded to {}", path.display());
                self.toast(format!("Downloaded \u{201c}{title}\u{201d}"));
            }
            Resp::Uploaded { done, failed } => {
                let songs = |n: usize| if n == 1 { "1 song".to_owned() } else { format!("{n} songs") };
                self.toast(match (done, failed.len()) {
                    (_, 0) => format!("Uploaded {}. It can take a minute for YouTube Music to finish processing.", songs(done)),
                    (0, _) => format!("Upload failed: {}", failed.join(", ")),
                    _ => format!("Uploaded {}; failed: {}", songs(done), failed.join(", ")),
                });
            }
            Resp::Lyrics { video_id, generation, lyrics, complete } => {
                if lyrics_response_is_current(self.shown().map(|t| t.id.as_str()), self.lyrics_generation, &video_id, generation) {
                    let available = self.lyric_prefs.available(&lyrics);
                    if !complete && available.is_empty() {
                        return;
                    }
                    let shown = self.lyric_prefs.choose(&video_id, &lyrics);
                    let missing: Vec<&str> = self.lyric_prefs.order.iter().filter(|(p, on)| *on && !available.contains(p)).map(|(p, _)| p.key()).collect();
                    log::info!(
                        "lyrics: showing {} ({}/{}); available: {}; no lyrics from: {}",
                        shown.map_or("nothing", |p| p.key()),
                        shown.and_then(|p| available.iter().position(|x| *x == p)).map_or(0, |i| i + 1),
                        available.len(),
                        available.iter().map(|p| p.key()).collect::<Vec<_>>().join(", "),
                        missing.join(", ")
                    );
                    self.lyrics = Some((video_id, lyrics));
                    // The words are the fallback the best part falls back to, so an
                    // answer about them can bring the button up on its own.
                    self.update_best_part();
                }
            }
            Resp::GeniusAbout { video_id, description } => {
                if let Some(Dialog::GeniusAbout { track, description: result }) = &mut self.dialog
                    && track.id == video_id
                {
                    *result = Some(description);
                }
            }
            Resp::AppleAlbumAbout { id, description } => {
                if let Some(Dialog::AppleAlbumAbout { id: shown, description: result, .. }) = &mut self.dialog
                    && *shown == id
                {
                    *result = Some(description);
                }
            }
            Resp::Segments { video_id, segments } => {
                if self.playing_id() == Some(video_id.as_str()) {
                    log::info!("sponsorblock: {} segment(s) for {video_id}", segments.len());
                    self.segments = Some((video_id, segments));
                }
            }
            Resp::BestPart { video_id, heat } => {
                self.curves_asked.remove(&video_id);
                log::info!("best part: {} replay curve for {video_id}", if heat.is_some() { "a" } else { "no" });
                self.curves.insert(video_id, heat);
                self.update_best_part();
            }
            Resp::AiLabel { video_id, ai } => {
                self.ai_flags.insert(video_id.clone(), ai);
                // The answer can land mid-song: the skip is owed at once, not next time.
                if ai && self.skip_ai && self.playing_id() == Some(video_id.as_str()) {
                    self.toast("Skipped: YouTube labels this one made with AI.");
                    self.next();
                }
            }
            Resp::LyricsExtras { video_id, source, target, extras } => {
                if self.shown().is_some_and(|t| t.id == video_id) {
                    self.lyrics_extras = Some((video_id, source, target, extras));
                }
            }
            Resp::PageArt { key, art } => self.page_art = Some((key, art.rgba)),
            Resp::Art { key, art } => {
                if self.mix_hold().is_none() && self.current_id() == Some(key.as_str()) {
                    self.accent = art.accent;
                    self.frost_art = Some((key.clone(), art.rgba.clone()));
                    if let Some(bg) = &self.bg {
                        bg.set_art(art.clone());
                    }
                    self.background_art = Some(art);
                    self.art_key = Some(key);
                    self.art_changed = now;
                }
            }
            Resp::AppleArtist { id, info } => {
                // A miss is cooled down rather than cached for the session: Apple's
                // search sometimes fails one time and answers the next.
                let key = format!("artist:{id}");
                self.apple.waiting.remove(&key);
                match info {
                    Some(artwork) => {
                        self.apple.missed.remove(&key);
                        self.apple_artists.insert(id, Some(artwork));
                    }
                    None => {
                        self.apple_artists.remove(&id);
                        self.apple.missed.insert(key, std::time::Instant::now());
                    }
                }
            }
            Resp::ArtistSignature { key, signature } => {
                self.signature_waiting.remove(&key);
                match signature {
                    Some(s) => {
                        self.signature_missed.remove(&key);
                        self.signature_images.insert(key, (s.width, s.height, s.rgba));
                    }
                    None => {
                        self.signature_missed.insert(key, std::time::Instant::now());
                    }
                }
            }
            Resp::HiResSourceChecked { key, result } => {
                self.hires_checking.remove(&key);
                self.hires_checks.insert(key, result);
            }
            Resp::AppleCover { key, motion } => {
                self.apple.waiting.remove(&key);
                match motion.and_then(|m| m.square) {
                    Some(url) => {
                        self.apple.missed.remove(&key);
                        self.apple.covers.insert(key, Some(url));
                    }
                    None => {
                        self.apple.missed.insert(key, std::time::Instant::now());
                    }
                }
            }
            Resp::MusicVideo { key, video } => {
                // Only the song the player is still on: an answer about one it skipped
                // past is dropped, and the next try asks again.
                if self.video.asked.as_deref() == Some(key.as_str()) {
                    self.video.none = video.is_none();
                    match video {
                        Some(v) => self.video.stream = Some(v),
                        // Nothing for this song, after both tries: say it, and let the
                        // note time itself out rather than sit over the artwork.
                        None => self.video.miss(),
                    }
                }
            }
            Resp::Canvas { key, canvas } => {
                // Only the song the player is still on: an answer about one it has moved
                // past leaves the next song's ask to make its own.
                if self.canvas.asked.as_deref() == Some(key.as_str()) {
                    self.canvas.url = canvas;
                }
            }
            Resp::AppleFeed { path, shelves } => {
                self.apple_feeds.remove(&path);
                // An empty answer means Apple's page didn't load: keep nothing, so the
                // YouTube feed carries the page and the next visit asks again.
                if shelves.is_empty() {
                    self.apple_shelves.remove(&path);
                } else {
                    self.apple_shelves.insert(path, shelves);
                }
                self.loading = false;
            }
            Resp::AppleCollection { url, collection } => {
                self.apple_collection_waiting.remove(&url);
                match collection {
                    Some(c) => {
                        self.apple_collections.insert(url, c);
                    }
                    None => {
                        self.apple_collections.remove(&url);
                    }
                }
                self.loading = false;
            }
            Resp::AppleOpened { apple, resolved } => {
                let name = match &apple {
                    crate::model::Target::Apple { title, .. } => title.clone(),
                    _ => String::new(),
                };
                match resolved {
                    Some(t) => self.actions.push(Action::Open(t)),
                    None if name.is_empty() => {}
                    None => self.toast(format!("YouTube Music has no copy of {name}.")),
                }
            }
            Resp::Moods(moods) => {
                self.moods_loading = false;
                self.mood = super::pages::mood_for_hour(&moods);
                self.moods = moods;
            }
            // A mood's own queue: what its playlists hold, shuffled, played from a
            // random song rather than the first one YouTube put up.
            Resp::MoodStation { name, tracks } => {
                self.mood_loading = false;
                let mut tracks = if self.play_songs { tracks.into_iter().filter(Track::is_song).collect() } else { tracks };
                if self.skip_ai {
                    tracks.retain(|t| !t.ai_labelled());
                }
                if tracks.is_empty() {
                    self.toast(format!("{name} has nothing to play right now."));
                } else {
                    self.queue_source = None;
                    let start = super::shuffled_start(tracks.len());
                    self.play_list_filling(tracks, start, None, Some(true));
                    self.toast(format!("Playing {name}"));
                }
            }
            Resp::Radio { seed, tracks } => {
                self.radio_pending = false;
                // A radio offers suggestions, nothing the user clicked: with songs-only on its
                // videos and podcast episodes step out. In a playlist the user played, a video
                // stays, and its song copy is found when it comes to play.
                let mut tracks = if self.play_songs { tracks.into_iter().filter(Track::is_song).collect() } else { tracks };
                // The same for AI: a suggested song saying AI made it is enough to leave it out.
                if self.skip_ai {
                    tracks.retain(|t| !t.ai_labelled());
                }
                // The same seed comes back in the same order every time: mixing the
                // suggestions means each listen is its own run, not a replay.
                super::shuffle(&mut tracks);
                let was_at_end = self.queue.add_radio(&seed, tracks);
                if was_at_end && self.queue.index.is_some() && !self.buffering && !self.playing() {
                    // The track ended while radio was loading: continue now.
                    self.next();
                } else if !self.buffering {
                    self.prefetch_next();
                }
            }
            // Unless something else was asked to play meanwhile; shuffled as last asked.
            Resp::PlayQueue { target, tracks } => {
                if let Some((p, shuffled)) = &self.play_pending
                    && *p == target
                {
                    let shuffled = *shuffled;
                    self.queue_source = Some(target);
                    let start = if shuffled { super::shuffled_start(tracks.len()) } else { 0 };
                    self.play_list_filling(tracks, start, None, Some(shuffled));
                }
            }
            Resp::Liked { video_id, like } => {
                self.lists.edits.confirm_likes(std::slice::from_ref(&video_id), &[]);
                if like {
                    self.liked.insert(video_id);
                }
            }
            Resp::QuickPicksMore { seed, tracks } => {
                if let Some(h) = &mut self.home {
                    h.picks_loading = false;
                    if let Some(shelf) = h.shelves.iter_mut().find(|s| s.title == "Quick picks")
                        && let ShelfKind::Songs { tracks: picks, .. } = &mut shelf.kind
                        && picks.iter().any(|t| t.id == seed)
                    {
                        h.picks_expanded = true;
                        let mut seen: HashSet<String> = picks.iter().map(|t| t.id.clone()).collect();
                        picks.extend(tracks.into_iter().filter(|t| seen.insert(t.id.clone())).take(24));
                    }
                }
            }
            Resp::LikeProgress { taken, done, total, like } => {
                if !like {
                    let tracks: Vec<Track> = taken.iter().filter_map(|id| self.unliking.remove(id)).collect();
                    self.set_liked(&tracks, false);
                }
                if done == 0 {
                    // A Spotify transfer is adding to Liked Music (maybe paused): this waits for it.
                    self.toast("Waiting for the transfer to finish adding to Liked Music…");
                } else if total > 1 && done < total {
                    let note = if self.backend.api().limited() { " (YouTube Music is limiting requests; waiting)" } else { "" };
                    self.toast(format!("{} {done} of {total} songs…{note}", if like { "Liking" } else { "Removing likes" }));
                }
            }
            Resp::LikedMany { video_ids, failed, like } => self.on_liked_many(video_ids, failed, like),
            Resp::PlaylistCreated { id, songs } => {
                self.request_library();
                self.toast(match songs {
                    0 => "Playlist created".to_owned(),
                    1 => "Song added to new playlist".to_owned(),
                    n => format!("{n} songs added to new playlist"),
                });
                self.go(Page::Playlist(id));
            }
            Resp::PlaylistChanged { id, message } => self.on_playlist_changed(id, message),
            Resp::Collaboration(c) => {
                if let Some(Dialog::Collaborate { id, info, busy, .. }) = &mut self.dialog
                    && *id == c.playlist_id
                {
                    *info = Some(c);
                    *busy = false;
                }
            }
            Resp::PlayingAs { generation, listed, song } => {
                // For the track it was looked up for: joining a jam swaps the queue without a new play.
                if generation == self.generation
                    && self.current_id() == Some(listed.as_str())
                    && let Some(track) = self.current().cloned()
                {
                    let shown = match song {
                        // The song keeps the listed track's album and art when it has none.
                        Some(song) => {
                            let song = Track { album: song.album.or(track.album.clone()), thumbs: if song.thumbs.is_empty() { track.thumbs.clone() } else { song.thumbs }, ..song };
                            self.playing_as = Some(PlayingAs { generation, listed: track.id.clone(), song: song.clone() });
                            song
                        }
                        None => {
                            self.playing_as = None;
                            track
                        }
                    };
                    if self.mix_hold().is_none() {
                        self.show_in_media(&shown);
                        self.refresh_lyrics(shown);
                    }
                }
            }
            Resp::PlayError { generation, msg } => self.on_play_error(generation, msg),
            Resp::AudioInfo { generation, info } => {
                // The stream that answered may already have been skipped past.
                if generation == self.generation {
                    self.audio_info = Some((generation, info));
                    self.upgrading_quality = false;
                    self.upgrade_asked = false;
                }
            }
            Resp::StreamStats { generation, stats } => {
                if generation == self.generation {
                    self.stream_stats = Some((generation, stats));
                }
            }
            Resp::UpgradingQuality { generation, active } => {
                if generation == self.generation {
                    self.upgrading_quality = active;
                    // The player's "Upgrade quality" ends here one way or the other: a
                    // stream would have announced itself first, so this one had nothing.
                    if !active && std::mem::take(&mut self.upgrade_asked) && self.audio_info.is_none() {
                        self.toast("None of your hi-res sources has a copy of this song.");
                    }
                }
            }
            Resp::ServerQueue(q) => self.adopt_server_queue(q),
            Resp::Account { name, photo } => {
                self.account_name = name.or(self.account_name.take());
                self.account_avatar = photo.or(self.account_avatar.take());
            }
            Resp::Channels(c) => self.channels = Some(c),
            Resp::SwitchedChannel { page_id, epoch, error } => {
                let name = self.switching_to.take().unwrap_or_else(|| "another channel".to_owned());
                match error {
                    Some(e) => self.toast(e),
                    None => {
                        // Everything reloads as after signing in, but it's the same sign-in
                        // with the same channels: only which one is used changed.
                        let channels = self.channels.take().map(|c| crate::backend::Channels { current: page_id, epoch, ..c });
                        let asked = self.channels_asked;
                        self.on_resp(Resp::LoggedIn(true), now);
                        (self.channels, self.channels_asked) = (channels, asked);
                        self.toast(format!("Switched to {name}"));
                    }
                }
            }
            Resp::LoggedIn(v) => self.on_logged_in(v, now),
            Resp::Error(e) => self.on_error(e),
        }
    }

    /// The home feed, replacing the one shown.
    fn on_home(&mut self, page: HomePage) {
        // Until the account menu answers (Req::Account).
        if self.account_avatar.is_none() {
            self.account_avatar = page.shelves.iter().find(|s| s.title == "Listen again").and_then(|s| s.strap_thumb.clone());
        }
        let mut chips = page.chips;
        // The feed marks the active mood itself; keep the bar when it doesn't send chips.
        if chips.is_empty() {
            chips = self.home.as_ref().map(|h| h.chips.clone()).unwrap_or_default();
        }
        self.home = Some(HomeState {
            chips,
            shelves: page.shelves,
            continuation: page.continuation,
            loading_more: None,
            picks_loading: false,
            picks_expanded: false,
        });
        self.home_loading = false;
        if self.page == Page::Home {
            self.loading = false;
        }
    }

    /// Liking or unliking many songs at once has finished: `failed` are the ones YouTube
    /// Music refused.
    fn on_liked_many(&mut self, video_ids: Vec<String>, failed: Vec<String>, like: bool) {
        // Any left (a retry took them) leave the list now.
        if !like {
            let rest: Vec<Track> = video_ids.iter().filter_map(|id| self.unliking.remove(id)).collect();
            self.set_liked(&rest, false);
            for id in &failed {
                self.unliking.remove(id);
            }
        }
        log::debug!("like={like} answered: {} taken, {} refused {:?}", video_ids.len(), failed.len(), failed.iter().take(5).collect::<Vec<_>>());
        self.lists.edits.confirm_likes(&video_ids, &failed);
        // The refused ones come back as they were with a reload.
        if !failed.is_empty() {
            self.request_liked(true);
        }
        let count = video_ids.len();
        let mut msg = format!("{} {count} {}", if like { "Liked" } else { "Removed likes from" }, if count == 1 { "song" } else { "songs" });
        if count == 0 {
            msg = format!("YouTube Music refused all {} songs; try again in a little while", failed.len());
        } else if !failed.is_empty() {
            msg += &format!("; YouTube Music refused {}", failed.len());
        }
        self.toast(msg);
    }

    /// A playlist was edited, added to, removed from, saved or deleted; `message` says which.
    fn on_playlist_changed(&mut self, id: String, message: &'static str) {
        self.request_library();
        if message == "Playlist deleted" {
            // Its load is dropped too, and the queue stops waiting for it.
            self.lists.forget(&id);
            if self.queue.fill.as_ref().is_some_and(|f| f.id == id) {
                self.queue.fill = None;
            }
            let gone = Page::Playlist(id);
            if self.page == gone {
                self.go(Page::Library(LibTab::Playlists));
            }
            // Back and Forward skip it.
            self.back.retain(|p| *p != gone);
            self.back.dedup();
            self.forward.retain(|p| *p != gone);
            self.forward.dedup();
        } else {
            if message == "Removed from playlist" {
                self.lists.edits.confirm_removal(&id);
            }
            // Kept for going back (or playing): reload it. What YouTube Music still
            // lists after a removal is dropped as it arrives.
            if self.lists.known(&id) {
                self.load_list(&id, false, true);
            }
        }
        self.toast(message);
    }

    /// A song couldn't play: skip it, or stop when skipping can't help.
    fn on_play_error(&mut self, generation: u64, msg: String) {
        if generation == self.generation {
            self.buffering = false;
            if self.mix_from.take().is_some() {
                self.pending_mix = None;
                self.audio.send(AudioCmd::Stop);
                self.release_mix();
            }
            let title = self.current().map(|t| t.title.clone()).unwrap_or_default();
            let reason = if msg.contains("age-restricted") || msg.contains("confirm your age") {
                "it's age-restricted".to_owned()
            } else {
                msg
            };
            let has_next = !self.queue.at_end() && self.queue.index.is_some();
            // Skipping can't help when the account is the problem: the rest of
            // an album like this needs it too. Stop on the song instead.
            if let Some(why) = account_block(&reason, self.logged_in) {
                self.skip_streak = 0;
                self.toast(why.replace("{title}", &title));
            } else if has_next && self.skip_streak < MAX_SKIPS {
                // Don't stall the queue on one unplayable song.
                self.skip_streak += 1;
                self.toast(format!("Skipped \"{title}\": {reason}"));
                self.next();
            } else {
                self.skip_streak = 0;
                self.toast(format!("Can't play \"{title}\": {reason}"));
            }
        }
    }

    /// Signed in or out: what belonged to the last account goes, and the new one's home,
    /// library and likes load.
    fn on_logged_in(&mut self, v: bool, now: f64) {
        self.logged_in = v;
        self.channels = None;
        self.channels_asked = None;
        // Recent searches belong to the account.
        self.suggestions = Default::default();
        self.suggest_sel = None;
        self.forgetting = None;
        self.suggest_round += 1;
        self.suggest_cache.clear();
        self.forgets_pending = 0;
        self.suggest_due = Some(now);
        self.account_name = None;
        self.account_avatar = None;
        self.sidebar_cache = None;
        self.library = None;
        self.history = None;
        self.uploads = None;
        // Your own playlists show differently (and private ones not at all) to another
        // account, and its likes aren't this one's.
        self.lists.clear();
        self.lists.edits = Default::default();
        self.liked.clear();
        self.unliking.clear();
        self.queue.fill = None;
        self.play_pending = None;
        if self.page_list().is_some() {
            self.refresh();
        }
        self.home = None;
        self.home_loading = true;
        self.backend.request(Req::Home(None));
        if v {
            self.request_library();
            self.request_liked(false);
            self.backend.request(Req::Account);
        }
        self.toast(if v { "Signed in" } else { "Signed out" });
    }

    /// A request failed: pages waiting for it stop waiting, and the error shows.
    fn on_error(&mut self, e: String) {
        if let Some(Dialog::Collaborate { info, busy, .. }) = &mut self.dialog {
            *busy = false;
            // Nothing to show if it never loaded.
            if info.is_none() {
                self.dialog = None;
            }
        }
        // A page still waiting for its first data shows a retry instead of loading forever.
        self.load_failed |= self.loading || (self.page == Page::Home && self.home_loading);
        self.loading = false;
        self.home_loading = false;
        self.radio_pending = false;
        self.moods_loading = false;
        self.mood_loading = false;
        if let Some(h) = &mut self.home {
            h.loading_more = None;
            h.picks_loading = false;
        }
        self.toast(e);
    }
}

fn lyrics_response_is_current(shown: Option<&str>, current_generation: u64, video_id: &str, generation: u64) -> bool {
    shown == Some(video_id) && current_generation == generation
}

/// Unplayable songs skipped in a row before playback stops.
const MAX_SKIPS: u32 = 3;

/// When a song failed because of the account (Premium-only, or needs signing in),
/// the message to show instead of skipping: the rest of an album like that fails the
/// same way.
fn account_block(msg: &str, logged_in: bool) -> Option<&'static str> {
    let m = msg.to_ascii_lowercase();
    if m.contains("premium") {
        Some("\"{title}\" needs YouTube Music Premium")
    } else if !logged_in && (m.contains("sign in") || m.contains("age-restricted")) {
        Some("Sign in to play \"{title}\"")
    } else {
        None
    }
}

#[cfg(test)]
mod account_block_tests {
    use super::{account_block, lyrics_response_is_current};

    #[test]
    fn lyrics_responses_require_the_current_song_and_request() {
        assert!(lyrics_response_is_current(Some("song"), 2, "song", 2));
        assert!(!lyrics_response_is_current(Some("song"), 2, "song", 1));
        assert!(!lyrics_response_is_current(Some("other"), 2, "song", 2));
        assert!(!lyrics_response_is_current(None, 2, "song", 2));
    }

    #[test]
    fn account_errors_stop_instead_of_skipping() {
        assert!(account_block("sign in to play this song", false).is_some());
        assert!(account_block("sign in to play this song", true).is_none());
        assert!(account_block("This video is only available to Music Premium members", true).is_some());
        assert!(account_block("decode: end of stream", false).is_none());
    }
}

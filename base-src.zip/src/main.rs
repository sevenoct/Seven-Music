#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod appicon;
mod apple;
mod album_logo;
mod artist_signature;
mod fullscreen;
mod grab;
mod proxy;
mod renderer;
mod art;
mod audio;
mod bitperfect;
#[cfg(target_os = "linux")]
mod child_process;
mod backend;
mod bestpart;
mod bidi;
mod deeplink;
mod discord;
mod dash;
mod downloads;
mod hires;
mod images;
mod jam;
mod innertube;
mod jsc;
mod lastfm;
mod login;
mod lyrics;
mod media;
mod model;
mod motion;
mod opus;
mod preset;
mod remux;
mod shader;
mod sponsorblock;
mod stream;
mod theme;
mod transfer;
mod translate;
mod tray;
mod turnstile;
mod ui;
mod update;
mod webmusic;
mod ytdlp;
mod ytm;
mod vault;
mod ytmapi;

use std::sync::Arc;
#[cfg(not(target_os = "linux"))]
use std::sync::OnceLock;

use crossbeam_channel::unbounded;

/// Window size on first launch, and the smallest it may be (points).
pub const DEFAULT_SIZE: [f32; 2] = [1200.0, 780.0];
pub const MIN_SIZE: [f32; 2] = [760.0, 480.0];

fn main() -> eframe::Result {
    // Child-process modes for the webview windows (see login.rs / turnstile.rs).
    let mut args = std::env::args_os().skip(1);
    if let (Some(flag), Some(dir)) = (args.next(), args.next()) {
        // The parent hands its proxy setting down through the environment.
        proxy::init(std::path::Path::new(""));
        if flag == login::FLAG {
            login::child_main(login::Site::Google, dir.into());
            return Ok(());
        }
        if flag == login::SPOTIFY_FLAG {
            login::child_main(login::Site::Spotify, dir.into());
            return Ok(());
        }
        if flag == turnstile::FLAG {
            turnstile::child_main(dir.into());
            return Ok(());
        }
    }
    // A party link (`bitchord://party/CODE` or the https invite page): hand it to the running
    // instance if there is one, else join once this one is up. Before `init_logging`,
    // which would truncate the running instance's log file.
    let link = deeplink::from_args();
    #[cfg(target_os = "linux")]
    let instance = match deeplink::Instance::open(
        &data_dir(),
        link.as_ref(),
        std::env::args_os().any(|arg| arg == deeplink::RELAUNCH_FLAG),
    )
    .map_err(|err| eframe::Error::AppCreation(err.into()))?
    {
        Some(instance) => instance,
        None => return Ok(()),
    };
    #[cfg(not(target_os = "linux"))]
    if match &link {
        Some(link) => deeplink::forward_to_running(&link.url()),
        None => deeplink::forward_show(),
    } {
        return Ok(());
    }
    if let Some(link) = link {
        deeplink::push(link);
    }
    init_logging();
    guard_settings(&data_dir());
    update::clean_portable();
    stream::init_dev_hooks();
    proxy::init(&data_dir());

    // Dev hook: YTM_BACKGROUND opens the window off-screen, unfocused and off the
    // taskbar, so automated test runs don't pop up over whatever the user is doing.
    let background = std::env::var_os("YTM_BACKGROUND").is_some();
    let mut viewport = egui::ViewportBuilder::default()
        .with_title("BitChord")
        .with_app_id("bitchord")
        .with_inner_size(DEFAULT_SIZE)
        .with_min_inner_size(MIN_SIZE)
        // Windows: the app draws its own title bar (see `ui::titlebar`).
        .with_decorations(!ui::custom_titlebar())
        .with_icon(appicon::get(appicon::load(&data_dir())).icon_data().expect("bundled icons are valid PNGs"));
    if background {
        viewport = viewport.with_position([-4000.0, 0.0]).with_inner_size([1920.0, 1057.0]).with_active(false).with_taskbar(false);
    }
    let renderer = renderer::init(&data_dir());
    let options = eframe::NativeOptions {
        viewport,
        #[cfg(target_os = "linux")]
        event_loop_builder: if std::env::var_os("DISPLAY").is_some_and(|display| !display.is_empty())
            && std::env::var_os("BITCHORD_NATIVE_WAYLAND").is_none()
        {
            Some(Box::new(|builder| {
                use winit::platform::x11::EventLoopBuilderExtX11;
                builder.with_x11();
            }))
        } else {
            None
        },
        renderer: match renderer {
            renderer::Renderer::OpenGl => eframe::Renderer::Glow,
            renderer::Renderer::Wgpu => eframe::Renderer::Wgpu,
        },
        persist_window: !background,
        // Settings live with the rest of the data: beside the portable exe, or a
        // YTM_DATA_DIR profile (e.g. a clean signed-out one for screenshots).
        persistence_path: Some(data_dir().join("app.ron")),
        // No MSAA/depth/stencil: egui doesn't need them and they cost VRAM.
        multisampling: 0,
        depth_buffer: 0,
        stencil_buffer: 0,
        // Dev hook: YTM_FPS paces frames itself (see `dev_pace`), so vsync is off.
        glow_options: eframe::egui_glow::GlowConfiguration { vsync: std::env::var_os("YTM_FPS").is_none(), ..Default::default() },
        wgpu_options: renderer::wgpu_options(),
        ..Default::default()
    };

    let create_app = |cc: &eframe::CreationContext<'_>| -> anyhow::Result<ui::App> {
        #[cfg(target_os = "linux")]
        let wake = tray::wayland::wake;
        // Background threads wake the UI through this.
        #[cfg(not(target_os = "linux"))]
        static CTX: OnceLock<egui::Context> = OnceLock::new();
        #[cfg(not(target_os = "linux"))]
        let _ = CTX.set(cc.egui_ctx.clone());
        #[cfg(not(target_os = "linux"))]
        let wake = || {
            if let Some(c) = CTX.get() {
                c.request_repaint();
            }
        };

        // Receive launch requests for this profile in the primary instance.
        #[cfg(target_os = "linux")]
        instance.listen(wake)?;
        #[cfg(not(target_os = "linux"))]
        deeplink::listen(wake);
        // Keep `bitchord:` links pointing at this copy; dev builds leave it alone
        // (even with YTM_UPDATE_FORCE).
        if update::installed() && !cfg!(debug_assertions) {
            deeplink::register_protocol();
        }

        let volume = cc
            .storage
            .and_then(|s| s.get_string("volume"))
            .and_then(|v| v.parse().ok())
            .unwrap_or(0.8f32);
        // The slider is logarithmic unless turned off. A volume saved before that
        // existed was linear: move it to where it sounds the same.
        let log_setting = cc.storage.and_then(|s| s.get_string("log_volume"));
        let log_volume = log_setting.as_deref().is_none_or(|v| v == "1");
        let volume = if log_setting.is_none() {
            volume.cbrt()
        } else {
            volume
        };
        // Dev hook: YTM_MUTE starts silent and never persists the volume.
        let volume = if std::env::var_os("YTM_MUTE").is_some() {
            0.0
        } else {
            volume
        };

        let device = cc
            .storage
            .and_then(|s| s.get_string("output_device"))
            .filter(|d| !d.is_empty());

        let (audio_tx, audio_rx) = unbounded();
        let audio = audio::spawn(volume, log_volume, device, audio_tx, wake);

        let data_dir = data_dir();
        let (resp_tx, resp_rx) = unbounded();
        let backend = backend::Backend::new(data_dir, resp_tx, audio.clone(), Arc::new(wake))?;

        let (media_tx, media_rx) = unbounded();
        if let Some(h) = hwnd(cc) {
            appicon::set_hwnd(h);
            fullscreen::set_hwnd(h);
            grab::set_hwnd(h);
            ui::set_titlebar_hwnd(h);
            // eframe sets only the small icon; the taskbar button wants the big one.
            appicon::set_window_icon(appicon::get(appicon::load(backend.data_dir())));
        }
        let media = media::Media::new(hwnd(cc), media_tx, wake);

        // Which GL driver this is, for reports of drawing problems (Windows on ARM runs
        // GL through Mesa's D3D12 layer).
        if let Some(gl) = &cc.gl {
            use eframe::glow::HasContext;
            // SAFETY: plain string queries on the current context.
            let (renderer, version) = unsafe {
                (
                    gl.get_parameter_string(eframe::glow::RENDERER),
                    gl.get_parameter_string(eframe::glow::VERSION),
                )
            };
            log::info!("gl: {renderer} ({version})");
        }
        if let Some(rs) = &cc.wgpu_render_state {
            let info = rs.adapter.get_info();
            log::info!(
                "wgpu: {} ({:?}, driver {} {})",
                info.name,
                info.backend,
                info.driver,
                info.driver_info
            );
        }
        let mut app = ui::App::new(
            backend,
            audio,
            ui::Channels {
                resp_rx,
                audio_rx,
                media_rx,
            },
            media,
            cc.storage,
        );
        app.setup_window(cc);
        Ok(app)
    };
    #[cfg(target_os = "linux")]
    let run = tray::wayland::run(options, create_app);
    #[cfg(not(target_os = "linux"))]
    let run = eframe::run_native(
        "BitChord",
        options,
        Box::new(|cc| Ok(Box::new(create_app(cc)?))),
    );
    #[cfg(target_os = "linux")]
    {
        tray::finish();
        child_process::HELPERS.finish();
    }
    // A wgpu window that won't open would fail the same way at every launch: go back
    // to OpenGL for the next one.
    if run.is_err() && renderer == renderer::Renderer::Wgpu {
        log::error!("renderer: {} failed to start; switching back to OpenGL", renderer::api_name());
        let _ = renderer::save(&data_dir(), renderer::Renderer::OpenGl);
    }
    run
}

// Each renderer owns its own background resources.
fn make_background(
    cc: &eframe::CreationContext<'_>,
    art: Option<&art::Art>,
) -> Option<shader::Background> {
    if std::env::var_os("YTM_NO_SHADER").is_some() {
        return None;
    }
    let idle;
    let art = if let Some(art) = art {
        art
    } else {
        idle = art::idle();
        &idle
    };
    match (&cc.gl, &cc.wgpu_render_state) {
        (Some(gl), _) => shader::Background::new(gl, art)
            .map_err(|err| log::warn!("background shader unavailable: {err:#}"))
            .ok(),
        (_, Some(rs)) => Some(shader::Background::new_wgpu(rs, art)),
        _ => None,
    }
}

#[cfg(windows)]
fn hwnd(cc: &eframe::CreationContext) -> Option<*mut std::ffi::c_void> {
    use raw_window_handle::{HasWindowHandle, RawWindowHandle};
    match cc.window_handle().ok()?.as_raw() {
        RawWindowHandle::Win32(h) => Some(h.hwnd.get() as *mut std::ffi::c_void),
        _ => None,
    }
}

#[cfg(not(windows))]
fn hwnd(_: &eframe::CreationContext) -> Option<*mut std::ffi::c_void> {
    None
}

/// Keep the settings file from taking the app's every setting down with it. A copy
/// killed mid-save (an update's installer, say) can leave `app.ron` half-written,
/// which reads at the next launch as settings wiped. A good copy is backed up as it's
/// seen; an unreadable one is set aside and the backup put in its place.
pub(crate) fn guard_settings(dir: &std::path::Path) {
    use std::io::BufReader;
    let path = dir.join("app.ron");
    let Ok(file) = std::fs::File::open(&path) else { return };
    let reads = ron::de::from_reader::<_, std::collections::HashMap<String, String>>(BufReader::new(file)).is_ok();
    if reads {
        let _ = std::fs::copy(&path, dir.join("app.ron.bak"));
        return;
    }
    log::warn!("settings: {} is unreadable; setting it aside", path.display());
    let _ = std::fs::rename(&path, dir.join("app.ron.bad"));
    let bak = dir.join("app.ron.bak");
    if std::fs::copy(&bak, &path).is_ok() {
        log::info!("settings: restored the last good copy");
    }
}

/// Log to stderr in debug builds; release builds have no console, so log to a file
/// next to the settings (overwritten each launch).
fn init_logging() {
    let mut builder = env_logger::Builder::from_env(
        // A test build can be made more talkative: YTM_DEFAULT_LOG=warn,bitchord=debug cargo build.
        env_logger::Env::default().default_filter_or(option_env!("YTM_DEFAULT_LOG").unwrap_or("warn,bitchord=info")),
    );
    // Dev hook: YTM_LOG=<path> logs there (test runs beside a running copy).
    if let Some(path) = std::env::var_os("YTM_LOG") {
        if let Ok(file) = std::fs::File::create(path) {
            builder.target(env_logger::Target::Pipe(Box::new(file)));
        }
    } else if !cfg!(debug_assertions) {
        let dir = data_dir();
        let _ = std::fs::create_dir_all(&dir);
        // The last run's log too: reopening the app after a problem would otherwise wipe it.
        let _ = std::fs::rename(dir.join("ytm-rs.log"), dir.join("ytm-rs.prev.log"));
        if let Ok(file) = std::fs::File::create(dir.join("ytm-rs.log")) {
            builder.target(env_logger::Target::Pipe(Box::new(file)));
        }
    }
    builder.init();
}

/// Settings, caches and the sign-in: `data` beside the portable build's exe, else the
/// user's app data. Dev hook: YTM_DATA_DIR runs on a separate profile.
fn data_dir() -> std::path::PathBuf {
    if let Some(d) = std::env::var_os("YTM_DATA_DIR") {
        return d.into();
    }
    if let Some(dir) = update::portable_dir() {
        return dir.join("data");
    }
    directories::ProjectDirs::from("", "", "ytm-rs").expect("no home directory").data_dir().to_path_buf()
}
